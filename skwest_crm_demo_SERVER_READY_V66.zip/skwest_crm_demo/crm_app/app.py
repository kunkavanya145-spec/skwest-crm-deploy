import os, secrets, hashlib, secrets, sqlite3, webbrowser, threading, mimetypes, tempfile, shutil, json, zipfile, re
from pathlib import Path
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import xml.etree.ElementTree as ET

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'crm.db')
PORT = 8172
USERS = [(1,'Иван Коляда','manager','Менеджер'),(2,'Юлия Ипатова','head_manager','Главный менеджер'),(3,'Дмитрий','constructor','Конструктор'),(4,'Данил Потапов','shop_head','Начальник цеха'),(5,'Сергей Вармаховский','director','Генеральный директор')]
STAGES=['Новый заказ','Актуальный заказ','Конструктор','Себестоимость и сроки','КП и коэффициент','Утверждение директора','Согласование с заказчиком','Оплата','Изготовление заказа','Заказ завершён']
COLORS=['#22c55e','#3b82f6','#f97316','#a855f7','#ef4444','#06b6d4','#eab308','#ec4899']
CSS='''
*{box-sizing:border-box}body{margin:0;font-family:Arial,Helvetica,sans-serif;background:radial-gradient(circle at top left,#111827 0,#090d14 38%,#05070b 100%);color:#e7edf5}a{color:#93c5fd}h1,h2,h3{margin:0 0 12px;color:#fff}.top{background:#07101a;border-bottom:1px solid #1e2c40;position:sticky;top:0;z-index:10}.topbar{max-width:1500px;margin:0 auto;padding:10px 22px;display:grid;grid-template-columns:120px 280px 280px 1fr;align-items:center;gap:18px;min-height:104px}.logo{width:100px;height:80px;object-fit:contain}.title{font-size:22px;font-weight:900}.title span{color:#93c5fd}.title small{display:block;color:#9fb0c8;font-size:12px;margin-top:5px}.account{position:relative}.account button{width:100%;background:linear-gradient(180deg,#17263a,#101925);border:1px solid #365170;color:#fff;padding:10px 14px;border-radius:14px;font-weight:900;text-align:left;cursor:pointer}.account button small{display:block;color:#9fb0c8;margin-top:2px}.drop{display:none;position:absolute;left:0;top:calc(100% + 8px);width:280px;background:#111926;border:1px solid #334155;border-radius:16px;padding:8px;box-shadow:0 16px 38px rgba(0,0,0,.38)}.account:hover .drop{display:block}.drop a{display:block;padding:12px;border-radius:12px;text-decoration:none;color:#fff;font-weight:800}.drop a small{display:block;color:#94a3b8;font-weight:500}.drop a:hover{background:#17263a}.nav{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap}.nav a{position:relative;color:#e5eefb;text-decoration:none;font-weight:900;padding:12px 16px;border-radius:14px;background:#111926;border:1px solid #263243;min-width:118px;text-align:center}.nav a:hover{background:#17263a;border-color:#60a5fa}.navbadge{display:inline-flex;align-items:center;justify-content:center;min-width:22px;height:22px;padding:0 6px;margin-left:7px;border-radius:999px;background:linear-gradient(180deg,#ef4444,#b91c1c);color:#fff;font-size:12px;font-weight:900;box-shadow:0 0 18px rgba(239,68,68,.55);animation:badgePulse 1.2s infinite alternate ease-in-out}.wrap{padding:22px 20px 40px;max-width:1500px;margin:0 auto}.main{max-width:1280px;margin:0 auto}.card{background:linear-gradient(180deg,rgba(18,25,35,.98),rgba(12,17,24,.98));border:1px solid #1f2937;border-radius:20px;box-shadow:0 16px 40px rgba(0,0,0,.25);padding:20px;margin-bottom:18px}.muted{color:#9fb0c8}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px}.stat{background:#0d1522;border:1px solid #253143;border-radius:18px;padding:16px;min-height:116px}.stat b{font-size:31px;display:block;margin-top:6px}.green_text{color:#86efac}.yellow_text{color:#fde047}.red_text{color:#fca5a5}.blue_text{color:#93c5fd}.btn{display:inline-flex;align-items:center;justify-content:center;border:1px solid #2b6eea;border-radius:14px;background:linear-gradient(180deg,#3b82f6,#2563eb);color:white;padding:10px 14px;text-decoration:none;font-weight:900;cursor:pointer;margin:3px}.dashboard_compact{display:grid;grid-template-columns:1fr auto auto;gap:14px;align-items:center;padding:18px 20px}.dashboard_title h1{font-size:25px;margin-bottom:6px}.dashboard_title p{margin:0;color:#9fb0c8}.mini_stat{min-width:190px;padding:14px 16px;border-radius:17px;background:#0c1624;border:1px solid #253449}.mini_stat span{color:#9fb0c8;font-size:13px}.mini_stat b{display:block;margin-top:4px;font-size:28px;color:#fff}.financegrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(255px,1fr));gap:16px}.financecard{display:flex;gap:14px;align-items:flex-start;min-height:144px}.financeicon{width:58px;height:58px;display:flex;align-items:center;justify-content:center;font-size:28px;border-radius:18px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08)}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #253143;padding:12px;text-align:left}input{width:100%;padding:12px 13px;border:1px solid #334155;border-radius:14px;background:#0b1220;color:#f8fafc}.calendar{display:grid;grid-template-columns:repeat(7,minmax(150px,1fr));gap:10px;overflow:auto}.day{min-height:250px;border:1px solid #2563eb;border-radius:14px;background:#0b1320;padding:12px}.day b{font-size:18px}.day .small{font-size:12px;color:#bfdbfe}.weekend{background:#100f14!important;border-color:#481b25!important}.holiday{background:#231016!important;border-color:#ef4444!important}.short{background:#17170c!important;border-color:#eab308!important}.legend,.orderlegend{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px}.legend span,.orderlegendchip{display:inline-flex;align-items:center;gap:9px;padding:7px 10px;border-radius:999px;background:#0d1522;border:1px solid #334155;font-size:12px}.orderlegendchip i{width:12px;height:12px;border-radius:999px;display:inline-block}.orderblock{position:relative;overflow:hidden;border:1px solid #3b82f6;border-radius:13px;padding:10px;margin:8px 0;font-size:12px;line-height:1.25;color:#fff}.calendar_card_top{display:flex;justify-content:flex-end;min-height:28px;margin-bottom:3px}.calendar_open{display:inline-block;margin-top:6px;margin-right:8px;padding:5px 8px;border-radius:8px;background:#0f172a;border:1px solid #60a5fa;color:#bfdbfe;text-decoration:none;font-size:11px;font-weight:800}.draghint{display:block;margin-top:5px;color:#bfdbfe;font-size:11px}.draggable_task{user-select:none}.draggable_task[draggable="true"]{cursor:grab}.draggable_task[draggable="true"]:active{cursor:grabbing}.dragging_now{opacity:.45;transform:scale(.98)}.saving_move{outline:2px dashed #fbbf24!important;filter:saturate(1.25);animation:savingPulse .6s infinite alternate}.move_saved{outline:2px solid #22c55e!important;box-shadow:0 0 24px rgba(34,197,94,.35)!important}.dropday.dragover{outline:3px dashed #60a5fa!important;outline-offset:-7px!important;background:#0b1d33!important}.fire_toggle{width:30px;height:30px;border-radius:999px;border:1px solid #475569;background:linear-gradient(180deg,#334155,#111827);filter:grayscale(1);opacity:.75;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,.25);position:relative;z-index:5}.fire_toggle:hover{filter:grayscale(.1);opacity:1;border-color:#fb923c;box-shadow:0 0 18px rgba(249,115,22,.45)}.fire_toggle.active{filter:grayscale(0);opacity:1;border-color:#fb923c;background:linear-gradient(180deg,#fb923c,#c2410c);box-shadow:0 0 22px rgba(249,115,22,.8);animation:urgentFire 1.15s infinite alternate ease-in-out}.urgent_order{border-color:#ff5a1f!important;background:radial-gradient(circle at top left,rgba(255,90,31,.28),transparent 34%),radial-gradient(circle at bottom right,rgba(255,0,0,.22),transparent 38%),linear-gradient(180deg,rgba(74,15,5,.96),rgba(15,23,42,.96))!important;box-shadow:0 0 0 1px rgba(255,90,31,.65),0 0 18px rgba(255,90,31,.65),0 0 34px rgba(239,68,68,.38)!important;animation:urgentFire 1.15s infinite alternate ease-in-out}.urgent_order::before{content:"🔥 СРОЧНО";display:inline-flex;margin-bottom:5px;padding:3px 7px;border-radius:999px;background:rgba(255,90,31,.25);border:1px solid rgba(255,186,73,.55);color:#ffd166;font-size:10px;font-weight:900}.readonly{background:#0d1522;border:1px solid #334155;border-radius:14px;padding:13px;color:#bfdbfe}.notice{background:rgba(245,158,11,.10);border:1px solid rgba(245,158,11,.35);color:#fde68a;padding:13px;border-radius:16px;font-weight:800;margin-bottom:12px}.stagebar{display:grid;grid-template-columns:repeat(auto-fit,minmax(105px,1fr));gap:8px;margin:12px 0}.stage{padding:11px;border-radius:14px;background:#111926;border:1px solid #263243;color:#9fb0c3;font-size:13px;font-weight:900;text-align:center}.done{background:rgba(34,197,94,.14);color:#bbf7d0}.current{background:rgba(59,130,246,.16);border-color:#60a5fa;color:#dbeafe}.chain{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}.chainitem{border-radius:18px;color:white;padding:16px;font-weight:900}.chainitem small{display:block;opacity:.9;margin-top:6px}.task{display:block;text-decoration:none;color:#e7edf5;background:#0d1522;border:1px solid #26364b;border-radius:18px;padding:16px;margin:10px 0}@keyframes urgentFire{from{box-shadow:0 0 0 1px rgba(255,90,31,.55),0 0 14px rgba(255,90,31,.45),0 0 28px rgba(239,68,68,.25)}to{box-shadow:0 0 0 1px rgba(255,186,73,.85),0 0 26px rgba(255,90,31,.85),0 0 48px rgba(239,68,68,.55)}}@keyframes badgePulse{from{transform:scale(1)}to{transform:scale(1.08)}}@keyframes savingPulse{from{opacity:.65}to{opacity:1}}@media(max-width:1100px){.topbar{grid-template-columns:100px 1fr}.account,.nav{grid-column:1/-1}.calendar{grid-template-columns:repeat(2,minmax(150px,1fr))}.dashboard_compact{grid-template-columns:1fr}.mini_stat{min-width:0}}

/* V66 REAL FIRE EFFECT FOR URGENT ORDERS */
.orderblock.urgent_order,
.urgent_order{
  position:relative!important;
  overflow:hidden!important;
  border:2px solid #ff6b00!important;
  background:
    radial-gradient(circle at 15% 0%, rgba(255,230,90,.28), transparent 22%),
    radial-gradient(circle at 85% 0%, rgba(255,95,0,.30), transparent 26%),
    radial-gradient(circle at 50% 100%, rgba(255,0,0,.23), transparent 38%),
    linear-gradient(180deg, rgba(70,12,4,.98), rgba(18,10,10,.98))!important;
  box-shadow:
    0 0 0 1px rgba(255,219,92,.72),
    0 0 12px rgba(255,116,0,.85),
    0 0 28px rgba(255,59,0,.70),
    0 0 52px rgba(255,0,0,.42)!important;
  animation:fireCardPulse 0.85s infinite alternate ease-in-out!important;
}

.orderblock.urgent_order::before,
.urgent_order::before{
  content:"";
  position:absolute;
  left:-10%;
  right:-10%;
  bottom:-18px;
  height:72px;
  z-index:0;
  pointer-events:none;
  background:
    radial-gradient(ellipse at 10% 100%, rgba(255,234,110,.95) 0 12%, transparent 23%),
    radial-gradient(ellipse at 25% 100%, rgba(255,120,0,.95) 0 16%, transparent 31%),
    radial-gradient(ellipse at 42% 100%, rgba(255,215,72,.98) 0 14%, transparent 28%),
    radial-gradient(ellipse at 60% 100%, rgba(255,75,0,.96) 0 18%, transparent 34%),
    radial-gradient(ellipse at 78% 100%, rgba(255,235,110,.92) 0 12%, transparent 25%),
    radial-gradient(ellipse at 92% 100%, rgba(255,85,0,.90) 0 15%, transparent 31%);
  filter:blur(.2px);
  opacity:.72;
  transform-origin:bottom center;
  animation:flameTongues 0.55s infinite alternate ease-in-out;
}

.orderblock.urgent_order::after,
.urgent_order::after{
  content:"";
  position:absolute;
  inset:-3px;
  border-radius:inherit;
  z-index:0;
  pointer-events:none;
  background:
    linear-gradient(90deg,
      transparent,
      rgba(255,216,70,.0),
      rgba(255,216,70,.75),
      rgba(255,80,0,.95),
      rgba(255,216,70,.75),
      transparent);
  opacity:.35;
  filter:blur(10px);
  animation:fireBorderRun 1.15s linear infinite;
}

.orderblock.urgent_order > *,
.urgent_order > *{
  position:relative;
  z-index:2;
}

.orderblock.urgent_order b,
.urgent_order b{
  text-shadow:
    0 0 6px rgba(255,225,120,.65),
    0 0 14px rgba(255,94,0,.45)!important;
}

.orderblock.urgent_order .time,
.urgent_order .time{
  color:#ffe08a!important;
  font-weight:800!important;
}

.orderblock.urgent_order .calendar_card_top::before,
.urgent_order .calendar_card_top::before{
  content:"🔥 САМЫЙ ВАЖНЫЙ";
  display:inline-flex;
  align-items:center;
  justify-content:center;
  margin-right:auto;
  padding:4px 9px;
  border-radius:999px;
  background:linear-gradient(180deg, rgba(255,190,66,.30), rgba(255,82,0,.20));
  border:1px solid rgba(255,210,90,.72);
  color:#ffe9a8;
  font-size:10px;
  font-weight:900;
  letter-spacing:.04em;
  box-shadow:0 0 14px rgba(255,100,0,.55);
  animation:fireBadgeBlink .75s infinite alternate ease-in-out;
}

.fire_toggle.active{
  filter:grayscale(0)!important;
  opacity:1!important;
  border-color:#ffd166!important;
  background:radial-gradient(circle at 50% 35%, #fff2a8 0 16%, #ff8a00 35%, #d62828 70%)!important;
  box-shadow:
    0 0 0 2px rgba(60,10,0,.75),
    0 0 12px rgba(255,190,66,.95),
    0 0 28px rgba(255,75,0,.75)!important;
  animation:fireIconBurn .48s infinite alternate ease-in-out!important;
}

@keyframes fireCardPulse{
  from{
    box-shadow:
      0 0 0 1px rgba(255,219,92,.55),
      0 0 10px rgba(255,116,0,.65),
      0 0 22px rgba(255,59,0,.52),
      0 0 38px rgba(255,0,0,.30);
    filter:saturate(1.05) brightness(1);
  }
  to{
    box-shadow:
      0 0 0 1px rgba(255,238,140,.95),
      0 0 18px rgba(255,150,0,.95),
      0 0 42px rgba(255,59,0,.85),
      0 0 72px rgba(255,0,0,.55);
    filter:saturate(1.22) brightness(1.08);
  }
}

@keyframes flameTongues{
  from{
    transform:translateY(8px) scaleX(.96) scaleY(.78);
    opacity:.48;
  }
  to{
    transform:translateY(-3px) scaleX(1.05) scaleY(1.08);
    opacity:.85;
  }
}

@keyframes fireBorderRun{
  from{transform:translateX(-45%) rotate(0deg)}
  to{transform:translateX(45%) rotate(0deg)}
}

@keyframes fireBadgeBlink{
  from{opacity:.75;transform:scale(.98)}
  to{opacity:1;transform:scale(1.03)}
}

@keyframes fireIconBurn{
  from{transform:scale(1) rotate(-3deg)}
  to{transform:scale(1.12) rotate(4deg)}
}

/* V66: restored informative main block */
.main_info_card{padding:22px!important}
.main_info_top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin-bottom:18px}
.main_info_top h1{margin:0 0 8px 0;font-size:30px}
.main_info_top p{margin:0;line-height:1.45}
.main_role_badge{padding:9px 13px;border-radius:999px;background:#0c1624;border:1px solid #35517a;color:#dbeafe;font-weight:900;white-space:nowrap}
.main_info_grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-top:12px}
.main_info_tile{position:relative;overflow:hidden;padding:16px;border-radius:18px;background:linear-gradient(180deg,#0c1624,#0a1220);border:1px solid #26364d;min-height:128px;box-shadow:inset 0 1px 0 rgba(255,255,255,.035)}
.main_info_tile::after{content:"";position:absolute;right:-18px;top:-18px;width:86px;height:86px;border-radius:50%;background:rgba(96,165,250,.06)}
.tile_icon{font-size:24px;margin-bottom:8px}
.main_info_tile span{display:block;color:#9fb0c8;font-size:14px}
.main_info_tile b{display:block;margin-top:5px;color:#fff;font-size:30px;line-height:1}
.main_info_tile small{display:block;margin-top:7px;color:#d7e6fa}
.main_info_tile.alert{border-color:rgba(239,68,68,.45);box-shadow:0 0 22px rgba(239,68,68,.12),inset 0 1px 0 rgba(255,255,255,.035)}
.main_info_tile.alert .tile_icon{animation:badgePulse 1s infinite alternate}
.main_action_row{display:flex;gap:12px;flex-wrap:wrap;margin-top:18px}
@media (max-width:1000px){.main_info_grid{grid-template-columns:repeat(2,minmax(0,1fr))}.main_info_top{flex-direction:column}}
@media (max-width:620px){.main_info_grid{grid-template-columns:1fr}.main_info_top h1{font-size:24px}}

/* V66: more alive flame - stronger fire with sparks and moving tongues */
.orderblock.urgent_order,
.urgent_order{
  position:relative!important;
  overflow:hidden!important;
  border:2px solid #ff6b00!important;
  background:
    radial-gradient(circle at 18% 0%, rgba(255,242,143,.38), transparent 22%),
    radial-gradient(circle at 84% 6%, rgba(255,91,0,.38), transparent 26%),
    radial-gradient(circle at 50% 100%, rgba(255,0,0,.32), transparent 42%),
    linear-gradient(180deg, rgba(86,14,3,.99), rgba(18,8,8,.99))!important;
  box-shadow:
    0 0 0 1px rgba(255,219,92,.8),
    0 0 16px rgba(255,116,0,.95),
    0 0 38px rgba(255,59,0,.82),
    0 0 80px rgba(255,0,0,.52)!important;
  animation:fireCardPulseV66 .55s infinite alternate ease-in-out!important;
}

/* big flame layer */
.orderblock.urgent_order::before,
.urgent_order::before{
  content:""!important;
  position:absolute!important;
  left:-18%!important;
  right:-18%!important;
  bottom:-28px!important;
  height:105px!important;
  z-index:0!important;
  pointer-events:none!important;
  background:
    radial-gradient(ellipse at 8% 100%, rgba(255,245,145,.98) 0 10%, rgba(255,118,0,.82) 16%, transparent 31%),
    radial-gradient(ellipse at 21% 100%, rgba(255,110,0,.98) 0 17%, rgba(210,30,0,.78) 27%, transparent 42%),
    radial-gradient(ellipse at 37% 100%, rgba(255,238,105,.98) 0 12%, rgba(255,124,0,.9) 22%, transparent 38%),
    radial-gradient(ellipse at 53% 100%, rgba(255,70,0,.98) 0 20%, rgba(255,194,74,.72) 31%, transparent 48%),
    radial-gradient(ellipse at 70% 100%, rgba(255,235,120,.95) 0 13%, rgba(255,89,0,.86) 24%, transparent 42%),
    radial-gradient(ellipse at 88% 100%, rgba(255,100,0,.96) 0 18%, rgba(200,0,0,.72) 31%, transparent 47%);
  filter:blur(.15px) saturate(1.35);
  opacity:.86;
  transform-origin:bottom center;
  animation:flameTonguesV66 .34s infinite alternate ease-in-out;
}

/* sparks + heat wave */
.orderblock.urgent_order::after,
.urgent_order::after{
  content:""!important;
  position:absolute!important;
  inset:-8px!important;
  border-radius:inherit!important;
  z-index:1!important;
  pointer-events:none!important;
  background:
    radial-gradient(circle at 18% 72%, rgba(255,238,120,.92) 0 2px, transparent 3px),
    radial-gradient(circle at 38% 48%, rgba(255,120,0,.85) 0 2px, transparent 3px),
    radial-gradient(circle at 66% 62%, rgba(255,230,90,.82) 0 2px, transparent 3px),
    radial-gradient(circle at 82% 36%, rgba(255,80,0,.78) 0 2px, transparent 3px),
    linear-gradient(90deg, transparent, rgba(255,216,70,.16), rgba(255,80,0,.25), transparent);
  opacity:.75;
  filter:blur(.25px);
  animation:sparksRiseV66 .75s infinite linear;
}

.orderblock.urgent_order > *,
.urgent_order > *{position:relative;z-index:3}

.orderblock.urgent_order b,
.urgent_order b{
  text-shadow:
    0 0 7px rgba(255,235,150,.9),
    0 0 18px rgba(255,90,0,.72),
    0 0 30px rgba(255,0,0,.45)!important;
}

.orderblock.urgent_order .calendar_card_top::before,
.urgent_order .calendar_card_top::before{
  content:"🔥 САМЫЙ ВАЖНЫЙ";
  display:inline-flex;
  align-items:center;
  justify-content:center;
  margin-right:auto;
  padding:4px 9px;
  border-radius:999px;
  background:linear-gradient(180deg, rgba(255,214,95,.36), rgba(255,82,0,.28));
  border:1px solid rgba(255,226,120,.86);
  color:#fff0b8;
  font-size:10px;
  font-weight:900;
  letter-spacing:.04em;
  box-shadow:0 0 18px rgba(255,100,0,.75);
  animation:fireBadgeBlinkV66 .42s infinite alternate ease-in-out;
}

.fire_toggle.active{
  filter:grayscale(0)!important;
  opacity:1!important;
  border-color:#ffd166!important;
  background:radial-gradient(circle at 50% 32%, #fff6b7 0 13%, #ffb000 28%, #ff5a00 50%, #b91c1c 76%)!important;
  box-shadow:
    0 0 0 2px rgba(60,10,0,.75),
    0 0 14px rgba(255,220,90,.95),
    0 0 32px rgba(255,75,0,.85)!important;
  animation:fireIconBurnV66 .28s infinite alternate ease-in-out!important;
}

@keyframes fireCardPulseV66{
  from{filter:saturate(1.12) brightness(1);transform:translateY(0)}
  to{filter:saturate(1.45) brightness(1.12);transform:translateY(-1px)}
}
@keyframes flameTonguesV66{
  0%{transform:translateY(12px) scaleX(.92) scaleY(.72) skewX(-2deg);opacity:.58}
  50%{transform:translateY(1px) scaleX(1.06) scaleY(1.08) skewX(2deg);opacity:.92}
  100%{transform:translateY(-8px) scaleX(.98) scaleY(1.22) skewX(-1deg);opacity:.78}
}
@keyframes sparksRiseV66{
  0%{transform:translateY(18px);opacity:.35}
  40%{opacity:.92}
  100%{transform:translateY(-42px);opacity:.12}
}
@keyframes fireBadgeBlinkV66{
  from{opacity:.82;transform:scale(.98)}
  to{opacity:1;transform:scale(1.06)}
}
@keyframes fireIconBurnV66{
  from{transform:scale(1) rotate(-5deg)}
  to{transform:scale(1.15) rotate(6deg)}
}

/* V66 clickable main tiles */
a.main_info_tile{
  text-decoration:none!important;
  color:inherit!important;
  display:block;
  transition:transform .16s ease, border-color .16s ease, box-shadow .16s ease, background .16s ease;
}
a.main_info_tile:hover{
  transform:translateY(-3px);
  border-color:#60a5fa!important;
  box-shadow:0 16px 36px rgba(2,8,23,.36),0 0 24px rgba(96,165,250,.12)!important;
  background:linear-gradient(180deg,#101d2f,#0b1526)!important;
}
a.main_info_tile:active{transform:translateY(-1px) scale(.99)}
.order_list{display:flex;flex-direction:column;gap:10px;margin-top:14px}
.order_list_card{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:16px;
  padding:14px 16px;
  border-radius:16px;
  background:#0c1624;
  border:1px solid #26364d;
  color:#fff;
  text-decoration:none;
  transition:.16s ease;
}
.order_list_card:hover{
  transform:translateY(-2px);
  border-color:#60a5fa;
  box-shadow:0 12px 28px rgba(2,8,23,.35);
}
.order_list_card small{display:block;color:#9fb0c8;margin-top:4px}
.order_list_card strong{display:block;text-align:right;margin-top:7px;color:#93c5fd}
.urgent_small{display:inline-flex;margin-left:8px;padding:3px 8px;border-radius:999px;background:rgba(249,115,22,.18);border:1px solid rgba(249,115,22,.55);color:#fed7aa;font-size:12px}
@media (max-width:700px){.order_list_card{flex-direction:column;align-items:flex-start}.order_list_card strong{text-align:left}}

/* V66 clickable finance cards and details pages */
a.finance_click{
  text-decoration:none!important;
  color:inherit!important;
  cursor:pointer;
  transition:transform .16s ease, border-color .16s ease, box-shadow .16s ease, background .16s ease;
}
a.finance_click:hover{
  transform:translateY(-3px);
  border-color:#60a5fa!important;
  box-shadow:0 16px 36px rgba(2,8,23,.36),0 0 24px rgba(96,165,250,.14)!important;
}
.finance_total_big{
  font-size:42px;
  font-weight:900;
  margin:16px 0 12px;
}
.finance_detail_list{display:flex;flex-direction:column;gap:12px;margin-top:12px}
.finance_detail_row{
  display:grid;
  grid-template-columns:1fr 380px;
  gap:18px;
  padding:16px;
  border-radius:18px;
  background:#0c1624;
  border:1px solid #26364d;
}
.finance_detail_main b{font-size:18px}
.finance_detail_main small{display:block;margin-top:5px;color:#9fb0c8}
.finance_status_line{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:10px;color:#dbeafe}
.finance_dates{margin-top:10px;color:#9fb0c8;font-size:13px;line-height:1.45}
.finance_detail_money strong{display:block;font-size:28px;text-align:right}
.finance_detail_money small{display:block;margin:8px 0 10px;color:#dbeafe;font-size:12px;line-height:1.4;text-align:right}
.finance_detail_money .calendar_open{float:right}
@media (max-width:900px){
  .finance_detail_row{grid-template-columns:1fr}
  .finance_detail_money strong,.finance_detail_money small{text-align:left}
  .finance_detail_money .calendar_open{float:none}
}

/* V66 order calendar and daily task calendar */
.weekheads{display:grid;grid-template-columns:repeat(7,1fr);gap:8px;margin-bottom:8px}
.weekheads b{padding:10px 12px;border-radius:12px;background:#0c1624;border:1px solid #26364d}
.orders_calendar,.tasks_calendar{display:grid;grid-template-columns:repeat(7,1fr);gap:8px}
.order_day,.task_day{min-height:155px;padding:10px;border-radius:14px;background:#08111f;border:1px solid #2563eb;display:flex;flex-direction:column;gap:8px}
.order_day.empty,.task_day.empty{opacity:.25}
.order_short,.daily_task{display:block;text-decoration:none;color:#fff;padding:9px;border-radius:12px;border:1px solid #334155;background:#0d1828;transition:.15s ease}
.order_short:hover,.daily_task:hover{transform:translateY(-2px);border-color:#60a5fa;box-shadow:0 10px 24px rgba(2,8,23,.35)}
.order_short b,.daily_task b{display:block;font-size:12px}
.order_short span,.daily_task span{display:block;font-weight:900;margin-top:3px}
.order_short small,.daily_task small{display:block;color:#9fb0c8;margin-top:3px}
.order_short.start{border-color:#22c55e;background:linear-gradient(180deg,#06351f,#0d1828)}
.order_short.finish{border-color:#f97316;background:linear-gradient(180deg,#3b1a05,#0d1828)}
.daily_task.new{border-color:#60a5fa}.daily_task.work{border-color:#facc15;background:linear-gradient(180deg,#322704,#0d1828)}.daily_task.done{border-color:#22c55e;background:linear-gradient(180deg,#06351f,#0d1828)}
.daily_task.urgent_task{border-color:#fb923c;box-shadow:0 0 18px rgba(249,115,22,.28)}
.formgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.formgrid label{display:flex;flex-direction:column;gap:6px;color:#9fb0c8}.formgrid input,.formgrid select,.formgrid textarea{padding:11px;border-radius:12px;border:1px solid #334155;background:#0c1624;color:#fff}.formgrid textarea{min-height:90px}
@media(max-width:1100px){.orders_calendar,.tasks_calendar,.weekheads{grid-template-columns:repeat(2,1fr)}}@media(max-width:650px){.orders_calendar,.tasks_calendar,.weekheads,.formgrid{grid-template-columns:1fr}}

/* V66 clearer colors for order/task calendars */
.order_short{position:relative;overflow:hidden}
.order_short em{display:block;margin-top:4px;font-style:normal;color:#dbeafe;font-size:11px}
.order_short.start::before,.order_short.finish::before{content:"";position:absolute;left:0;top:0;bottom:0;width:5px}
.order_short.start::before{background:#22c55e}.order_short.finish::before{background:#f97316}
.oc1{border-color:#22c55e!important;background:linear-gradient(180deg,#064e3b,#0d1828)!important}
.oc2{border-color:#a855f7!important;background:linear-gradient(180deg,#3b0764,#0d1828)!important}
.oc3{border-color:#06b6d4!important;background:linear-gradient(180deg,#164e63,#0d1828)!important}
.oc4{border-color:#f59e0b!important;background:linear-gradient(180deg,#451a03,#0d1828)!important}
.oc5{border-color:#ef4444!important;background:linear-gradient(180deg,#450a0a,#0d1828)!important}
.oc6{border-color:#3b82f6!important;background:linear-gradient(180deg,#172554,#0d1828)!important}
.oc7{border-color:#ec4899!important;background:linear-gradient(180deg,#500724,#0d1828)!important}
.oc8{border-color:#84cc16!important;background:linear-gradient(180deg,#1a2e05,#0d1828)!important}
.oc9{border-color:#14b8a6!important;background:linear-gradient(180deg,#134e4a,#0d1828)!important}
.oc10{border-color:#f97316!important;background:linear-gradient(180deg,#431407,#0d1828)!important}
.order_color_legend,.task_legend{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.order_color_legend span,.task_legend span{padding:6px 10px;border-radius:999px;border:1px solid #334155;background:#0c1624;font-size:12px;font-weight:900}
.legend_start{color:#86efac}.legend_finish{color:#fdba74}
.day_head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.day_plus{width:28px;height:28px;border-radius:999px;background:#2563eb;color:#fff;text-decoration:none;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:900;box-shadow:0 0 14px rgba(37,99,235,.35)}
.day_plus:hover{background:#16a34a;transform:scale(1.06)}
.daily_task{border-width:2px!important}
.daily_task.uc1{border-color:#38bdf8!important}.task_legend .uc1{color:#38bdf8}
.daily_task.uc2{border-color:#f472b6!important}.task_legend .uc2{color:#f472b6}
.daily_task.uc3{border-color:#a78bfa!important}.task_legend .uc3{color:#a78bfa}
.daily_task.uc4{border-color:#fb923c!important}.task_legend .uc4{color:#fb923c}
.daily_task.uc5{border-color:#facc15!important}.task_legend .uc5{color:#facc15}
.daily_task.urgent_task{box-shadow:0 0 20px rgba(249,115,22,.42)!important}
.morning_reminder{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-top:12px;padding:12px 14px;border-radius:16px;background:linear-gradient(90deg,#3b1a05,#0c1624);border:1px solid #fb923c;color:#fed7aa}

/* V66 fire button in all calendars */
.order_fire_top,.task_fire_top,.production_fire_top{display:flex;justify-content:flex-end;min-height:24px;margin-bottom:4px;position:relative;z-index:5}
.fire_toggle{
  width:28px;height:28px;border-radius:999px;border:1px solid #475569;
  background:linear-gradient(180deg,#334155,#111827);
  filter:grayscale(1);opacity:.72;cursor:pointer;
  display:inline-flex;align-items:center;justify-content:center;
  box-shadow:0 4px 12px rgba(0,0,0,.25);
  position:relative;z-index:8;
}
.fire_toggle:hover{filter:grayscale(.15);opacity:1;border-color:#fb923c;box-shadow:0 0 18px rgba(249,115,22,.45)}
.fire_toggle.active{
  filter:grayscale(0)!important;opacity:1!important;border-color:#ffd166!important;
  background:radial-gradient(circle at 50% 32%,#fff6b7 0 13%,#ffb000 28%,#ff5a00 50%,#b91c1c 76%)!important;
  box-shadow:0 0 0 2px rgba(60,10,0,.75),0 0 14px rgba(255,220,90,.95),0 0 32px rgba(255,75,0,.85)!important;
  animation:fireIconBurnV66 .28s infinite alternate ease-in-out!important;
}
.fire_readonly{cursor:default!important}
.order_short.urgent_order,.daily_task.urgent_order{animation:fireCardPulseV66 .55s infinite alternate ease-in-out!important;box-shadow:0 0 18px rgba(255,116,0,.75),0 0 38px rgba(255,59,0,.5)!important}

/* V66 fixed calendar logic */
.deadline_list{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:12px}
.deadline_notice{display:block;text-decoration:none;color:#fff;padding:14px;border-radius:16px;border:1px solid #334155;background:#0c1624;transition:.16s ease}
.deadline_notice:hover{transform:translateY(-2px);border-color:#60a5fa;box-shadow:0 12px 28px rgba(2,8,23,.35)}
.deadline_notice b{display:block;font-size:18px;margin-bottom:5px}
.deadline_notice span{display:block;font-weight:900}
.deadline_notice small{display:block;margin-top:5px;color:#cbd5e1}
.deadline_notice.rem3{border-color:#60a5fa;background:linear-gradient(180deg,#0b2548,#0c1624)}
.deadline_notice.rem2{border-color:#facc15;background:linear-gradient(180deg,#3b3107,#0c1624)}
.deadline_notice.rem1{border-color:#ef4444;background:linear-gradient(180deg,#450a0a,#0c1624);box-shadow:0 0 22px rgba(239,68,68,.25)}
@media(max-width:900px){.deadline_list{grid-template-columns:1fr}}

/* V66 dashboard order calendar instead of current orders table */
.section_head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.dash_weekheads{display:grid;grid-template-columns:repeat(7,1fr);gap:8px;margin:12px 0 8px}
.dash_weekheads b{padding:9px 10px;border-radius:12px;background:#0c1624;border:1px solid #26364d}
.dashboard_orders_calendar{display:grid;grid-template-columns:repeat(7,1fr);gap:8px}
.dash_order_day{min-height:145px;padding:10px;border-radius:14px;background:#08111f;border:1px solid #2563eb;display:flex;flex-direction:column;gap:7px}
.dash_order_day.empty{opacity:.25}
.dash_day_head{font-weight:900;color:#fff;margin-bottom:2px}
.dash_order_item{display:block;text-decoration:none;color:#fff;padding:8px;border-radius:12px;border:1px solid #334155;background:#0d1828;transition:.15s ease}
.dash_order_item:hover{transform:translateY(-2px);border-color:#60a5fa;box-shadow:0 10px 24px rgba(2,8,23,.35)}
.dash_order_item b{display:block;font-size:12px}
.dash_order_item span{display:block;margin-top:3px;color:#dbeafe;font-weight:800}
.dash_order_item small{display:block;margin-top:4px;color:#86efac;font-weight:900}
.dash_order_item.start::before,.dash_order_item.finish::before{content:"";display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:5px}
.dash_order_item.start::before{background:#22c55e}
.dash_order_item.finish::before{background:#f97316}
.dash_more{font-size:12px;color:#9fb0c8;padding:4px 2px}
@media(max-width:1200px){.dashboard_orders_calendar,.dash_weekheads{grid-template-columns:repeat(2,1fr)}}
@media(max-width:650px){.dashboard_orders_calendar,.dash_weekheads{grid-template-columns:1fr}}

/* V66 workshop workers and production teams */
.inline_form{display:grid;grid-template-columns:2fr 1.4fr 1fr auto;gap:10px}
.inline_form input,.formgrid input,.formgrid select{padding:11px;border-radius:12px;border:1px solid #334155;background:#0c1624;color:#fff}
.team_grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.team_card{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:14px;border-radius:16px;background:#0c1624;border:2px solid #2563eb}
.team_card b{display:block;font-size:18px}
.team_card small{display:block;color:#9fb0c8;margin:4px 0}
.team_card span{display:block;color:#dbeafe}
.smallbtn{padding:8px 12px;font-size:12px}
.btn.danger{background:#7f1d1d!important}
.btn.purple{background:#7c3aed!important}
@media(max-width:900px){.inline_form,.team_grid{grid-template-columns:1fr}}

/* V66 archive/export fixes */
.export_grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:16px}
.export_card{display:block;text-decoration:none;color:#fff;padding:18px;border-radius:18px;background:#0c1624;border:1px solid #26364d;transition:.16s ease}
.export_card:hover{transform:translateY(-3px);border-color:#60a5fa;box-shadow:0 16px 36px rgba(2,8,23,.36)}
.export_card b{display:block;font-size:20px;margin-bottom:8px}
.export_card span{color:#9fb0c8}
@media(max-width:900px){.export_grid{grid-template-columns:1fr}}

/* V66 fixes */
.timer_grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.timer_card{display:block;text-decoration:none;color:#fff;padding:16px;border-radius:18px;background:#0c1624;border:1px solid #26364d}
.timer_card b,.timer_card span,.timer_card strong,.timer_card small{display:block;margin-bottom:6px}
.timer_card strong{font-size:20px;color:#93c5fd}
.bar{height:9px;border-radius:99px;background:#1f2937;overflow:hidden}.bar i{display:block;height:100%;background:#22c55e}
@media(max-width:900px){.timer_grid{grid-template-columns:1fr}}

/* V66 clearer colored financial pages and export location */
.finance_big_sum{display:inline-block;font-size:42px;font-weight:900;padding:12px 18px;border-radius:18px;margin:8px 0 14px}
.finance_green{background:rgba(34,197,94,.12)!important;border-color:#22c55e!important;color:#86efac!important}
.finance_yellow{background:rgba(250,204,21,.12)!important;border-color:#facc15!important;color:#fde047!important}
.finance_red{background:rgba(239,68,68,.12)!important;border-color:#ef4444!important;color:#fca5a5!important}
.finance_blue{background:rgba(59,130,246,.12)!important;border-color:#3b82f6!important;color:#93c5fd!important}
.finance_order_list{display:flex;flex-direction:column;gap:10px}
.finance_order_row{display:grid;grid-template-columns:1.3fr 1fr .8fr .9fr .8fr;gap:12px;align-items:center;text-decoration:none;color:#fff;padding:14px;border-radius:18px;background:#0c1624;border:2px solid #26364d;transition:.16s ease}
.finance_order_row:hover{transform:translateY(-2px);border-color:#60a5fa;box-shadow:0 12px 28px rgba(2,8,23,.35)}
.finance_order_row b,.finance_order_row strong{display:block}.finance_order_row small{display:block;color:#9fb0c8;margin-top:3px}
.status_badge{display:inline-flex;padding:7px 10px;border-radius:999px;font-weight:900;font-size:12px;border:1px solid #334155}
.status_new{background:#111827;color:#dbeafe;border-color:#475569}.status_agree{background:#312e81;color:#c4b5fd;border-color:#8b5cf6}.status_pay{background:#422006;color:#fde68a;border-color:#f59e0b}.status_work{background:#082f49;color:#7dd3fc;border-color:#0284c7}.status_done{background:#052e16;color:#86efac;border-color:#22c55e}.status_bad{background:#450a0a;color:#fca5a5;border-color:#ef4444}
.progress_pill{display:inline-flex;padding:7px 10px;border-radius:999px;background:#052e16;color:#86efac;border:1px solid #22c55e;font-weight:900}
.template_hint{display:grid;gap:8px;background:#08111f;border:1px solid #3b82f6;border-radius:16px;padding:14px;margin:14px 0}
.template_hint b{color:#fff}.template_hint span{color:#bfdbfe}.template_hint code{background:#111827;border:1px solid #334155;border-radius:8px;padding:3px 6px;color:#fde68a}
@media(max-width:950px){.finance_order_row{grid-template-columns:1fr}}

/* V66 order table prototype */
.order_table_scroll{overflow:auto;border:1px solid #26364d;border-radius:18px;background:#07101a;max-height:680px}
.order_proto_table{min-width:3200px;border-collapse:separate;border-spacing:0}
.order_proto_table th{position:sticky;top:0;background:#0f172a;color:#fff;z-index:2;border-bottom:2px solid #3b82f6;vertical-align:middle;text-align:center;font-size:12px;white-space:normal}
.order_proto_table td{background:#0b1320;border-bottom:1px solid #1f2937;border-right:1px solid #1f2937;padding:5px}
.order_proto_table tr:nth-child(even) td{background:#0d1624}
.order_proto_table input{min-width:130px;border:1px solid #26364d;background:#08111f;color:#e5eefb;border-radius:8px;padding:7px;font-size:12px}
.order_proto_table input.important_cell{background:#10233a;border-color:#60a5fa;color:#fff;font-weight:900}
.table_toolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px}
.ot_col_2{min-width:260px}.ot_col_26,.ot_col_28,.ot_col_29{background:#14532d!important}.ot_col_31{background:#422006!important}

/* V66: link start and finish of the same order */
.order_short.pair_hover_active,
.dash_order_item.pair_hover_active{
  transform:translateY(-4px) scale(1.025)!important;
  border-color:#ffffff!important;
  box-shadow:0 0 0 2px rgba(255,255,255,.55),0 0 24px rgba(96,165,250,.85),0 0 44px rgba(59,130,246,.45)!important;
  animation:orderPairJumpV66 .42s infinite alternate ease-in-out!important;
  z-index:20!important;
}
.order_short.pair_hover_active::after,
.dash_order_item.pair_hover_active::after{
  content:"этот же заказ";
  display:inline-block;
  margin-top:6px;
  padding:3px 7px;
  border-radius:999px;
  background:#ffffff;
  color:#0f172a;
  font-size:10px;
  font-weight:900;
}
@keyframes orderPairJumpV66{
  from{transform:translateY(-2px) scale(1.01)}
  to{transform:translateY(-8px) scale(1.035)}
}
.progress_pill{
  position:relative;
}
.finance_order_row .progress_pill{
  min-width:58px;
  justify-content:center;
}

/* V66 team editor and timer fixes */
.workers_form{grid-template-columns:2fr 1.4fr auto!important}
.team_actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.team_card b{font-size:18px}
.timer_grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
.timer_card{display:block;text-decoration:none;color:#fff;padding:16px;border-radius:18px;background:#0c1624;border:1px solid #26364d;transition:.16s ease}
.timer_card:hover{transform:translateY(-2px);border-color:#60a5fa}
.timer_card b,.timer_card span,.timer_card strong,.timer_card small,.timer_card em{display:block;margin-bottom:6px}
.timer_card strong{font-size:20px;color:#93c5fd}
.timer_card em{font-style:normal;color:#86efac;font-weight:900}
.bar{height:9px;border-radius:99px;background:#1f2937;overflow:hidden}.bar i{display:block;height:100%;background:#22c55e}
@media(max-width:900px){.timer_grid{grid-template-columns:1fr}.team_actions{justify-content:flex-start}}
'''

def db():
    con=sqlite3.connect(DB_PATH); con.row_factory=sqlite3.Row; return con

def now_sql(): return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
def esc(x):
    if x is None: return ''
    return str(x).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
def money(x): return f'{int(float(x or 0)):,}'.replace(',',' ')
def user_by_id(uid):
    con=db(); u=con.execute('select * from users where id=?',(uid,)).fetchone(); con.close(); return u

def get_user(uid):
    return user_by_id(uid)

def can_edit_calendar(uid):
    return workshop_can(uid)

def add_hours(start_dt,hours):
    cur=start_dt; left=float(hours or 0)
    while left>0:
        if cur.hour<9: cur=cur.replace(hour=9,minute=0,second=0,microsecond=0)
        if cur.hour>=18:
            cur=(cur+timedelta(days=1)).replace(hour=9,minute=0,second=0,microsecond=0)
            while cur.weekday()>=5: cur=(cur+timedelta(days=1)).replace(hour=9,minute=0,second=0,microsecond=0)
            continue
        end=cur.replace(hour=18,minute=0,second=0,microsecond=0); can=(end-cur).total_seconds()/3600; take=min(left,can)
        cur+=timedelta(hours=take); left-=take
        if left<=0: return cur
        cur=(cur+timedelta(days=1)).replace(hour=9,minute=0,second=0,microsecond=0)
        while cur.weekday()>=5: cur=(cur+timedelta(days=1)).replace(hour=9,minute=0,second=0,microsecond=0)
    return cur

def init_db():
    con=db(); c=con.cursor()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,role TEXT,title TEXT);
    CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,order_number TEXT,customer_name TEXT,customer_phone TEXT,short_description TEXT,current_stage TEXT,current_stage_index INTEGER,price_total REAL DEFAULT 0,paid_amount REAL DEFAULT 0,remaining_amount REAL DEFAULT 0,total_items INTEGER DEFAULT 1,done_items INTEGER DEFAULT 0,item_name TEXT DEFAULT 'изделий',is_urgent INTEGER DEFAULT 0,created_at TEXT,updated_at TEXT);
    CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,from_user_id INTEGER,to_user_id INTEGER,stage TEXT,message TEXT,status TEXT DEFAULT 'open',created_at TEXT,closed_at TEXT);
    CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,user_id INTEGER,action TEXT,old_stage TEXT,new_stage TEXT,comment TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS workers(id INTEGER PRIMARY KEY AUTOINCREMENT,full_name TEXT,position TEXT);
    CREATE TABLE IF NOT EXISTS production_steps(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,name TEXT,description TEXT,duration_hours REAL,start_date TEXT,end_date TEXT,color TEXT,sort_order INTEGER,status TEXT DEFAULT 'Не начат',manual_locked INTEGER DEFAULT 0,moved_at TEXT);
    CREATE TABLE IF NOT EXISTS step_workers(step_id INTEGER,worker_id INTEGER);
    CREATE TABLE IF NOT EXISTS calendar_moves(id INTEGER PRIMARY KEY AUTOINCREMENT,step_id INTEGER,order_id INTEGER,moved_by INTEGER,old_start TEXT,old_end TEXT,new_start TEXT,new_end TEXT,note TEXT,created_at TEXT);
    ''')
    c.execute('''CREATE TABLE IF NOT EXISTS workshop_workers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        position TEXT,
        phone TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS workshop_teams(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        color TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS workshop_team_members(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER,
        worker_id INTEGER
    )''')
    try:
        c.execute('alter table production_steps add column team_id INTEGER')
    except Exception:
        pass
    try:
        c.execute('alter table production_steps add column assigned_date TEXT')
    except Exception:
        pass
    try:
        c.execute('alter table production_steps add column manual_locked INTEGER DEFAULT 1')
    except Exception:
        pass

    c.execute('''CREATE TABLE IF NOT EXISTS order_table_overrides(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER,
        col_index INTEGER,
        value TEXT,
        updated_by INTEGER,
        updated_at TEXT,
        UNIQUE(order_id,col_index)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS daily_tasks(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        description TEXT,
        task_date TEXT,
        assigned_to INTEGER,
        created_by INTEGER,
        order_id INTEGER,
        status TEXT DEFAULT 'Новая',
        priority TEXT DEFAULT 'Обычная',
        done_at TEXT,
        created_at TEXT
    )''')
    try:
        c.execute('alter table orders add column planned_start TEXT')
    except Exception:
        pass
    try:
        c.execute('alter table orders add column planned_finish TEXT')
    except Exception:
        pass
    con.commit()

    for u in USERS: c.execute('insert or ignore into users(id,name,role,title) values(?,?,?,?)',u)
    for w in [(1,'Алексей Сварщик','Сварщик'),(2,'Павел Гибка','Оператор листогиба'),(3,'Олег Покраска','Маляр'),(4,'Игорь Сборка','Сборщик'),(5,'Николай Лазер','Оператор лазера')]: c.execute('insert or ignore into workers(id,full_name,position) values(?,?,?)',w)
    con.commit()
    if c.execute('select count(*) c from orders').fetchone()['c']==0: seed_demo(con)
    con.close()

def seed_demo(con):
    c=con.cursor(); cursor=datetime(2026,6,3,9,0)
    demos=[('CRM-1001','ООО Балтика','Металлические двери 4 шт',380000,266000,45,1,'дверей',42),('CRM-1002','ИП Орлов','Ламельный забор 22 м.п.',520000,364000,22,1,'м.п.',36),('CRM-1003','Мария Алексеева','Откатные ворота RAL 7024',460000,322000,1,0,'изделий',31),('CRM-1004','ООО Север','Противопожарные двери EI60 6 шт',690000,483000,45,16,'дверей',54),('CRM-1005','Антон Смирнов','Калитка и распашные ворота',310000,217000,1,0,'изделий',24),('CRM-1006','ЖК Приморский','Ограждения лестниц 18 м.п.',610000,427000,18,0,'м.п.',38),('CRM-1007','ООО Вектор','Алюминиевые двери 2 шт',740000,518000,2,0,'дверей',47),('CRM-1008','Павел Кузнецов','Навес металлический',295000,206500,1,0,'изделий',19)]
    for idx,(num,client,short,total,paid,qty,done,item,hours) in enumerate(demos):
        c.execute('insert into orders(order_number,customer_name,customer_phone,short_description,current_stage,current_stage_index,price_total,paid_amount,remaining_amount,total_items,done_items,item_name,created_at,updated_at) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(num,client,'+7 911 000-00-00',short,'Изготовление заказа',8,total,paid,total-paid,qty,done,item,now_sql(),now_sql()))
        oid=c.lastrowid; c.execute('insert into tasks(order_id,from_user_id,to_user_id,stage,message,created_at) values(?,?,?,?,?,?)',(oid,2,4,'Изготовление заказа','Выполнить производство по заказу.',now_sql()))
        for i,(name,hrs,wids) in enumerate([('Лазерная резка',hours*.16,[5]),('Листогиб деталей',hours*.18,[2]),('Сварка',hours*.34,[1]),('Зачистка и подготовка',hours*.10,[1]),('Покраска',hours*.14,[3]),('Сборка и контроль',hours*.08,[4])]):
            start=cursor; end=add_hours(start,round(hrs,1)); cursor=end
            c.execute('insert into production_steps(order_id,name,description,duration_hours,start_date,end_date,color,sort_order) values(?,?,?,?,?,?,?,?)',(oid,name,'Производственный этап',round(hrs,1),start.strftime('%Y-%m-%d %H:%M'),end.strftime('%Y-%m-%d %H:%M'),COLORS[idx%len(COLORS)],i+1))
            sid=c.lastrowid
            for wid in wids: c.execute('insert into step_workers(step_id,worker_id) values(?,?)',(sid,wid))
    con.commit()

def task_count(con,uid): return con.execute("select count(*) c from tasks where to_user_id=? and coalesce(status,'open')<>'Закрыта'",(uid,)).fetchone()['c']
def badge(n): return f'<span class="navbadge">{n}</span>' if n else ''


def fire_buttons_script(uid):
    can = 'true' if can_assign_tasks(uid) else 'false'
    js = """
<script>
function bindFireButtons(uid){
  const canFire = CAN_FIRE_VALUE;
  document.querySelectorAll('.fire_toggle').forEach(function(btn){
    if(!canFire){
      btn.classList.add('fire_readonly');
      btn.setAttribute('title','Срочный заказ. Менять могут Юлия и Сергей');
      return;
    }
    btn.addEventListener('mousedown', function(e){ e.stopPropagation(); });
    btn.addEventListener('dragstart', function(e){ e.preventDefault(); e.stopPropagation(); });
    btn.addEventListener('click', function(e){
      e.preventDefault();
      e.stopPropagation();
      const oid=this.dataset.orderid;
      fetch('/toggle_urgent_ajax',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'user='+encodeURIComponent(uid)+'&id='+encodeURIComponent(oid)
      }).then(async r=>{
        const txt=await r.text();
        if(!r.ok) throw new Error(txt || 'Ошибка');
        location.reload();
      }).catch(err=>alert('Ошибка срочности: '+err.message));
    });
  });
}
document.addEventListener('DOMContentLoaded',function(){ bindFireButtons(UID_HERE); });
</script>
"""
    return js.replace('UID_HERE', str(uid)).replace('CAN_FIRE_VALUE', can)



def order_pair_hover_script():
    return """<script>
function bindOrderPairHoverV66(){
  document.querySelectorAll('[data-order-id]').forEach(function(el){
    el.addEventListener('mouseenter', function(){
      var id=this.dataset.orderId;
      document.querySelectorAll('[data-order-id="'+id+'"]').forEach(function(x){
        x.classList.add('pair_hover_active');
      });
    });
    el.addEventListener('mouseleave', function(){
      var id=this.dataset.orderId;
      document.querySelectorAll('[data-order-id="'+id+'"]').forEach(function(x){
        x.classList.remove('pair_hover_active');
      });
    });
  });
}
document.addEventListener('DOMContentLoaded', bindOrderPairHoverV66);
</script>"""


SESSION_COOKIE='skwest_session'

DEFAULT_PASSWORDS={
    'Иван Коляда':'1111',
    'Юлия Ипатова':'2222',
    'Данил Потапов':'3333',
    'Сергей Вармаховский':'4444',
    'Дмитрий':'5555'
}

def hash_password(p):
    return hashlib.sha256(('skwest_salt_'+str(p)).encode('utf-8')).hexdigest()

def ensure_auth_tables(con):
    con.execute("""CREATE TABLE IF NOT EXISTS login_sessions(
        token TEXT PRIMARY KEY,
        user_id INTEGER,
        created_at TEXT
    )""")
    try:
        con.execute('alter table users add column password_hash TEXT')
    except Exception:
        pass
    users=con.execute("select * from users").fetchall()
    for u in users:
        need=True
        try:
            need=not bool(u['password_hash'])
        except Exception:
            need=True
        if need:
            pwd=DEFAULT_PASSWORDS.get(u['name'],'1234')
            try:
                con.execute("update users set password_hash=? where id=?",(hash_password(pwd),u['id']))
            except Exception:
                pass
    con.commit()

def parse_cookies(header):
    out={}
    for part in str(header or '').split(';'):
        if '=' in part:
            k,v=part.strip().split('=',1)
            out[k]=v
    return out

def current_user_id_from_cookie(handler):
    try:
        cookies=parse_cookies(handler.headers.get('Cookie',''))
        token=cookies.get(SESSION_COOKIE,'')
        if not token:
            return None
        con=db()
        ensure_auth_tables(con)
        r=con.execute("select user_id from login_sessions where token=?",(token,)).fetchone()
        con.close()
        return int(r['user_id']) if r else None
    except Exception:
        return None

def create_login_session(user_id):
    con=db()
    ensure_auth_tables(con)
    token=secrets.token_hex(24)
    con.execute("insert into login_sessions(token,user_id,created_at) values(?,?,?)",(token,user_id,now_sql()))
    con.commit()
    con.close()
    return token

def render_login(error=''):
    con=db()
    try:
        ensure_auth_tables(con)
        users=con.execute("select * from users order by id").fetchall()
    except Exception:
        users=[]
    con.close()
    opts=''.join(['<option value="%s">%s — %s</option>'%(u['id'],esc(u['name']),esc(u['title'])) for u in users])
    err='<div class="login_error">%s</div>'%esc(error) if error else ''
    body = (
        '<!doctype html><html><head><meta charset="utf-8"><title>Вход в CRM</title><style>'
        'body{margin:0;background:#050b14;color:#fff;font-family:Arial;min-height:100vh;display:flex;align-items:center;justify-content:center}'
        '.login{width:min(440px,92vw);background:#0c1624;border:1px solid #26364d;border-radius:24px;padding:28px;box-shadow:0 20px 70px rgba(0,0,0,.45)}'
        'h1{margin:0 0 8px;font-size:30px}.muted{color:#9fb0c8;margin-bottom:20px}'
        'label{display:block;margin:14px 0 6px;color:#cbd5e1}select,input{width:100%;box-sizing:border-box;padding:13px;border-radius:14px;border:1px solid #334155;background:#08111f;color:#fff;font-size:16px}'
        'button{width:100%;margin-top:18px;padding:14px;border:0;border-radius:14px;background:#2563eb;color:#fff;font-size:17px;font-weight:900;cursor:pointer}'
        'button:hover{background:#16a34a}.login_error{padding:10px 12px;background:#450a0a;border:1px solid #ef4444;color:#fecaca;border-radius:12px;margin:12px 0}'
        '.hint{margin-top:16px;padding:12px;border-radius:14px;background:#08111f;border:1px solid #334155;color:#9fb0c8;font-size:13px;line-height:1.5}'
        '</style></head><body><form class="login" method="post" action="/login">'
        '<h1>Вход в CRM</h1><div class="muted">Выберите свой аккаунт и введите личный пароль.</div>'+err+
        '<label>Аккаунт</label><select name="user_id">'+opts+'</select>'
        '<label>Пароль</label><input name="password" type="password" placeholder="Введите пароль" required>'
        '<button>Войти</button>'
        '<div class="hint"><b>Тестовые пароли:</b><br>Иван — 1111<br>Юлия — 2222<br>Данил — 3333<br>Сергей — 4444<br>Дмитрий — 5555</div>'
        '</form></body></html>'
    )
    return body

def render_profile(uid):
    u=get_user(uid)
    body=(
        '<div class="card"><h1>Мой аккаунт</h1>'
        '<table><tr><th>Имя</th><td>%s</td></tr><tr><th>Должность</th><td>%s</td></tr><tr><th>Роль</th><td>%s</td></tr></table>'
        '<form class="formgrid" method="post" action="/change_password"><input type="hidden" name="user" value="%s">'
        '<label>Новый пароль<input name="password" type="password" required></label>'
        '<button class="btn green">Изменить пароль</button></form>'
        '<a class="btn danger" href="/logout">Выйти</a></div>'
    )%(esc(u['name']),esc(u['title']),esc(u['role']),uid)
    return layout('Мой аккаунт',body,uid)


def layout(title,body,uid):
    con=db(); users=con.execute('select * from users order by id').fetchall(); tc=task_count(con,uid); con.close(); u=user_by_id(uid)
    items=''.join([f'<a href="/?user={x["id"]}">{esc(x["name"])}<small>{esc(x["title"])}</small></a>' for x in users])
    new=f'<a href="/new?user={uid}">Новый заказ</a>' if u['role']=='manager' else ''; workers=f'<a href="/workers?user={uid}">Рабочие</a>' if u['role']=='shop_head' else ''
    return f'''<!doctype html><html><head><meta charset="utf-8"><title>{esc(title)}</title><style>{CSS}</style></head><body><div class="top"><div class="topbar"><img class="logo" src="/assets/skwest_logo_header.png"><div class="title">CRM СК ВЕСТ <span>V66</span><small>Рабочая система заказов</small></div><div class="account"><button>Аккаунт: {esc(u['name'])}<small>{esc(u['title'])}</small></button><div class="drop">{items}</div></div><div class="nav"><a href="/?user={uid}">Главная</a><a href="/tasks?user={uid}">Мои задачи {badge(tc)}</a><a href="/orders_calendar?user={uid}">Календарь заказов</a><a href="/tasks_calendar?user={uid}">Календарь задач</a><a href="/calendar?user={uid}">Производство</a>{new}{workers}</div></div></div><div class="wrap"><main class="main">{body}</main></div>{order_pair_hover_script()}</body></html>'''


def user_name_by_id(uid):
    try:
        return get_user(int(uid))['name']
    except Exception:
        return 'Не назначен'

def task_status_class(status):
    if status=='Готово':
        return 'done'
    if status=='В работе':
        return 'work'
    return 'new'

def can_manage_daily_tasks(uid):
    return can_assign_tasks(uid)

def seed_daily_demo(con):
    orders=con.execute("select id from orders order by id").fetchall()
    base_dates=['2026-06-01','2026-06-02','2026-06-03','2026-06-04','2026-06-05','2026-06-08','2026-06-09','2026-06-10','2026-06-15','2026-06-16']
    for i,o in enumerate(orders):
        start=base_dates[i % len(base_dates)]
        finish=add_business_days_str(start,7+i)
        con.execute("update orders set planned_start=coalesce(planned_start,?), planned_finish=coalesce(planned_finish,?) where id=?",(start,finish,o['id']))
    cnt=con.execute("select count(*) c from daily_tasks").fetchone()['c']
    if cnt==0:
        demo=[
            ('Созвониться с заказчиком','Уточнить размеры и сроки','2026-06-01',1,2,1,'Новая','Обычная'),
            ('Отвезти краску','Передать RAL 7024 на объект','2026-06-01',1,2,2,'В работе','Срочная'),
            ('Проверить оплату','Уточнить поступление предоплаты','2026-06-02',2,5,3,'Новая','Обычная'),
            ('Передать эскиз','Отправить актуальные размеры','2026-06-02',3,2,1,'Готово','Обычная'),
            ('Согласовать срок с цехом','Проверить загрузку производства','2026-06-03',4,5,4,'В работе','Срочная'),
            ('Позвонить клиенту','Уточнить по КП и договору','2026-06-03',1,2,5,'Новая','Обычная'),
            ('Подготовить документы','Счёт и спецификация на оплату','2026-06-04',2,1,6,'Новая','Обычная'),
            ('Проверить детали','Короткий отчёт по производству','2026-06-04',4,5,7,'В работе','Обычная'),
            ('Напомнить об оплате','Связаться после выполнения','2026-06-05',2,5,8,'Новая','Обычная'),
            ('Забрать договор','Подписанный договор от клиента','2026-06-05',1,2,2,'Новая','Срочная'),
        ]
        for t in demo:
            con.execute("insert into daily_tasks(title,description,task_date,assigned_to,created_by,order_id,status,priority,created_at) values(?,?,?,?,?,?,?,?,?)",(*t,now_sql()))
    con.commit()

def month_calendar_days(year=2026, month=6):
    import calendar
    first, days = calendar.monthrange(year,month)
    cells=[None]*first + list(range(1,days+1))
    while len(cells)%7:
        cells.append(None)
    return cells

def analytics(con):
    rows=con.execute("select * from orders where current_stage<>'Заказ завершён'").fetchall(); paid=sum(float(r['paid_amount'] or 0) for r in rows); total=sum(float(r['price_total'] or 0) for r in rows); final=sum(float(r['remaining_amount'] or 0) for r in rows); prepay=max(total*.7-paid,0); return paid,prepay,final,total,len(rows)


def dashboard_orders_calendar_html(uid):
    con=db()
    try:
        seed_daily_demo(con)
    except Exception:
        pass
    try:
        orders=con.execute("select * from orders where current_stage<>'Заказ завершён' order by planned_start,id").fetchall()
    except Exception:
        orders=con.execute("select * from orders order by id").fetchall()
    year,month=2026,6
    by_day={}
    for o in orders:
        start=''
        finish=''
        try:
            start=(o['planned_start'] or o['created_at'] or '')[:10]
        except Exception:
            pass
        try:
            finish=(o['planned_finish'] or '')[:10]
        except Exception:
            pass
        if start:
            by_day.setdefault(start,[]).append((o,'Зашёл','start'))
        if finish:
            by_day.setdefault(finish,[]).append((o,'Финиш','finish'))
    try:
        days=month_calendar_days(year,month)
    except Exception:
        import calendar
        first,count=calendar.monthrange(year,month)
        days=[None]*first+list(range(1,count+1))
        while len(days)%7:
            days.append(None)
    cells=[]
    for d in days:
        if d is None:
            cells.append('<div class="dash_order_day empty"></div>')
            continue
        key='%s-%02d-%02d' % (year,month,d)
        items=''
        for o,label,kind in by_day.get(key,[])[:4]:
            try:
                color=order_color_class(o['id'])
            except Exception:
                color=''
            price = o['price_total'] if 'price_total' in o.keys() else (o['total_amount'] if 'total_amount' in o.keys() else 0)
            items += (
                '<a class="dash_order_item %s %s" data-order-id="%s" href="/chain?id=%s&user=%s">' % (kind,color,o['id'],o['id'],uid)
                + '<b>%s - %s</b>' % (esc(label),esc(o['order_number']))
                + '<span>%s</span>' % esc(o['customer_name'])
                + '<small>%s ₽</small>' % money(price)
                + '</a>'
            )
        if len(by_day.get(key,[]))>4:
            items += '<span class="dash_more">ещё %s</span>' % (len(by_day.get(key,[]))-4)
        cells.append('<div class="dash_order_day"><div class="dash_day_head">%s Июнь</div>%s</div>' % (d,items or '<span class=muted>Нет заказов</span>'))
    con.close()
    return (
        '<div class="card"><div class="section_head"><h2>Календарь заказов</h2>'
        + '<a class="calendar_open" href="/orders_calendar?user=%s">Открыть полностью</a></div>' % uid
        + '<p class="muted">На главной видно, когда заказ зашёл, когда должен закончиться, название и цену. Наведи на заказ — его начало и конец подсветятся вместе.</p>'
        + '<div class="dash_weekheads"><b>Пн</b><b>Вт</b><b>Ср</b><b>Чт</b><b>Пт</b><b>Сб</b><b>Вс</b></div>'
        + '<div class="dashboard_orders_calendar">'+''.join(cells)+'</div></div>'
    )



def next_business_day_str(date_str):
    try:
        d=datetime.strptime(date_str[:10],'%Y-%m-%d')
    except Exception:
        d=datetime.now()
    while d.weekday()>=5:
        d += timedelta(days=1)
    return d.strftime('%Y-%m-%d')

def add_business_days_str(date_str, days):
    try:
        d=datetime.strptime(date_str[:10],'%Y-%m-%d')
    except Exception:
        d=datetime.now()
    d=datetime.strptime(next_business_day_str(d.strftime('%Y-%m-%d')),'%Y-%m-%d')
    added=0
    while added<days:
        d += timedelta(days=1)
        if d.weekday()<5:
            added += 1
    return d.strftime('%Y-%m-%d')

def can_place_order_weekend(uid):
    try:
        return get_user(int(uid))['role'] in ('head_manager','director')
    except Exception:
        return False

def finance_value_for_order(o, ftype):
    try:
        total=float(o['price_total'] if 'price_total' in o.keys() else (o['total_amount'] if 'total_amount' in o.keys() else 0) or 0)
    except Exception:
        total=0
    try:
        paid=float(o['paid_amount'] if 'paid_amount' in o.keys() else 0 or 0)
    except Exception:
        paid=0
    try:
        prepay_percent=float(o['prepay_percent'] if 'prepay_percent' in o.keys() else 0 or 0)
    except Exception:
        prepay_percent=0
    required_prepay=round(total*prepay_percent/100)
    if ftype=='paid':
        return paid
    if ftype=='prepay':
        return max(required_prepay-paid,0)
    if ftype=='final':
        return max(total-paid,0) if paid>0 else 0
    if ftype=='active':
        return total
    return total


def render_dashboard(uid):
    con=db()
    total_work=0; paid,prepay,final,total,active=analytics(con); tc=task_count(con,uid); rows=con.execute('select * from orders order by id desc limit 8').fetchall(); con.close(); u=user_by_id(uid)
    order_rows=''.join([f'<tr><td><b>{esc(o["order_number"])}</b><br><span class="muted">{esc(o["customer_name"])}</span></td><td>{esc(o["short_description"])}</td><td>{esc(o["current_stage"])}</td><td>{money(o["price_total"])} ₽</td></tr>' for o in rows])
    body=f'''<div class="card main_info_card" style="border-color:#3b82f6;background:linear-gradient(135deg,#101827,#0f1b3d)">
    <div class="main_info_top">
        <div>
            <h1>ГЛАВНАЯ СТРАНИЦА CRM</h1>
            <p class="muted">Текущий аккаунт: <b>{esc(u["name"])}</b>. Здесь сразу видно, что происходит с задачами, заказами, календарём и производством.</p>
        </div>
        <div class="main_role_badge">{esc(u["title"])}</div>
    </div>

    <div class="main_info_grid">
        <a class="main_info_tile {'alert' if task_count else ''}" href="/tasks?user={uid}">
            <div class="tile_icon">🔔</div>
            <span>Мои задачи</span>
            <b>{task_count}</b>
            <small>{'Ждут вашего действия' if task_count else 'Новых задач нет'}</small>
        </a>
        <a class="main_info_tile" href="/orders?user={uid}">
            <div class="tile_icon">📦</div>
            <span>Активные заказы</span>
            <b>{active}</b>
            <small>Заказы в работе</small>
        </a>
        <a class="main_info_tile" href="/orders_calendar?user={uid}">
            <div class="tile_icon">📅</div>
            <span>Календарь заказов</span>
            <b>План</b>
            <small>Даты входа и завершения заказов</small>
        </a>
        <a class="main_info_tile" href="/production?user={uid}">
            <div class="tile_icon">⏱️</div>
            <span>Производство</span>
            <b>Таймер</b>
            <small>Сроки и текущие этапы</small>
        </a>
    </div>

    <div class="main_action_row">
        <a class="btn green" href="/tasks?user={uid}">Открыть мои задачи</a>
        <a class="btn orange" href="/orders_calendar?user={uid}">Календарь заказов</a> <a class="btn blue" href="/tasks_calendar?user={uid}">Календарь задач</a> <a class="btn" href="/calendar?user={uid}">Производство</a>
    </div>
</div><div class="card"><h2>Финансы компании по заказам</h2><div class="financegrid">
    <a class="stat financecard finance-green finance_click" href="/finance?type=paid&user={uid}"><div class="financeicon">💰</div><div class="financecontent"><span class="muted">Оплачено клиентами</span><b class="green_text">{money(paid)} ₽</b><small>Деньги уже в компании</small><div class="financehint">Показать заказы и расчёт</div></div></a>
    <a class="stat financecard finance-yellow finance_click" href="/finance?type=prepay&user={uid}"><div class="financeicon">⏳</div><div class="financecontent"><span class="muted">Ждём предоплату</span><b class="yellow_text">{money(prepay)} ₽</b><small>Для запуска производства</small><div class="financehint">Показать заказы и расчёт</div></div></a>
    <a class="stat financecard finance-red finance_click" href="/finance?type=final&user={uid}"><div class="financeicon">🧾</div><div class="financecontent"><span class="muted">Ждём финальную оплату</span><b class="red_text">{money(final)} ₽</b><small>Остаток после выполнения</small><div class="financehint">Показать заказы и расчёт</div></div></a>
    <a class="stat financecard finance-blue finance_click" href="/finance?type=active&user={uid}"><div class="financeicon">📦</div><div class="financecontent"><span class="muted">Активные заказы</span><b class="blue_text">{money(total_work)} ₽</b><small>Общая сумма в работе</small><div class="financehint">Показать заказы и расчёт</div></div></a>
    </div></div>{dashboard_orders_calendar_html(uid)}'''
    return layout('Главная',body,uid)

def order_color(order_number): return COLORS[sum(ord(c) for c in str(order_number)) % len(COLORS)]

def calendar_script(uid):
    can='true' if can_edit_calendar(uid) else 'false'
    return f'''<script>function initCalendarDrag(uid){{const canDrag={can};document.querySelectorAll('.fire_toggle').forEach(btn=>{{btn.addEventListener('mousedown',e=>e.stopPropagation());btn.addEventListener('dragstart',e=>{{e.preventDefault();e.stopPropagation();}});btn.addEventListener('click',e=>{{e.preventDefault();e.stopPropagation();let oid=btn.dataset.orderid;fetch('/toggle_urgent_ajax',{{method:'POST',headers:{{'Content-Type':'application/x-www-form-urlencoded'}},body:'user='+encodeURIComponent(uid)+'&id='+encodeURIComponent(oid)}}).then(async r=>{{let t=await r.text();if(!r.ok)throw new Error(t);location.reload();}}).catch(err=>alert('Ошибка срочности: '+err.message));}});}});if(!canDrag){{document.querySelectorAll('.draggable_task').forEach(el=>{{el.removeAttribute('draggable');el.classList.add('readonly_drag')}});return;}}let draggedEl=null,draggedStep=null,oldParent=null;document.querySelectorAll('.draggable_task').forEach(el=>{{el.setAttribute('draggable','true');el.addEventListener('dragstart',e=>{{if(e.target.classList.contains('fire_toggle')){{e.preventDefault();return;}}draggedEl=el;oldParent=el.parentElement;draggedStep=el.dataset.step;el.classList.add('dragging_now');e.dataTransfer.setData('text/plain',draggedStep);}});el.addEventListener('dragend',()=>el.classList.remove('dragging_now'));}});document.querySelectorAll('.dropday').forEach(day=>{{day.addEventListener('dragover',e=>{{e.preventDefault();day.classList.add('dragover');}});day.addEventListener('dragleave',()=>day.classList.remove('dragover'));day.addEventListener('drop',e=>{{e.preventDefault();day.classList.remove('dragover');let step=e.dataTransfer.getData('text/plain')||draggedStep;let date=day.dataset.date;if(!step||!date||!draggedEl)return;if(!confirm('Перенести задачу на '+date+'?'))return;let empty=day.querySelector('.small.muted');if(empty)empty.remove();day.appendChild(draggedEl);draggedEl.classList.add('saving_move');fetch('/move_step_calendar',{{method:'POST',headers:{{'Content-Type':'application/x-www-form-urlencoded'}},body:'user='+encodeURIComponent(uid)+'&step_id='+encodeURIComponent(step)+'&new_date='+encodeURIComponent(date)}}).then(async r=>{{let t=await r.text();if(!r.ok)throw new Error(t);draggedEl.classList.remove('saving_move');draggedEl.classList.add('move_saved');setTimeout(()=>location.reload(),600);}}).catch(err=>{{alert('Ошибка переноса: '+err.message);if(oldParent&&draggedEl)oldParent.appendChild(draggedEl);if(draggedEl)draggedEl.classList.remove('saving_move');}});}});}});}}document.addEventListener('DOMContentLoaded',()=>initCalendarDrag({uid}));</script>'''



def finance_type_info(ftype):
    data={
        'paid':('Оплачено клиентами','Деньги уже поступили в компанию','paid_amount','green_text'),
        'prepay':('Ждём предоплату','Сумма предоплаты, которую ещё нужно получить до запуска производства','prepay_wait','yellow_text'),
        'final':('Ждём финальную оплату','Остаток, который клиент должен оплатить после выполнения заказа','final_wait','red_text'),
        'active':('Активные заказы','Полная сумма всех заказов, которые сейчас находятся в работе','total_amount','blue_text')
    }
    return data.get(ftype,data['active'])

def finance_order_numbers(con, o):
    try:
        steps=con.execute("select name,start_date,end_date from production_steps where order_id=? order by sort_order,id",(o['id'],)).fetchall()
    except Exception:
        steps=[]
    started=''
    finished=''
    if steps:
        started=steps[0]['start_date'] or ''
        finished=steps[-1]['end_date'] or ''
    return started, finished

def finance_formula_text(o, ftype):
    try:
        total=float(o['price_total'] if 'price_total' in o.keys() else (o['total_amount'] if 'total_amount' in o.keys() else 0) or 0)
    except Exception:
        total=0
    try:
        paid=float(o['paid_amount'] if 'paid_amount' in o.keys() else 0 or 0)
    except Exception:
        paid=0
    try:
        prepay_percent=float(o['prepay_percent'] if 'prepay_percent' in o.keys() else 0 or 0)
    except Exception:
        prepay_percent=0
    required_prepay=round(total*prepay_percent/100)
    if ftype=='paid':
        return f"Оплачено = сумма оплат по заказу: {money(paid)} ₽"
    if ftype=='prepay':
        return f"Ждём предоплату = сумма заказа {money(total)} ₽ × {prepay_percent:.0f}% − оплачено {money(paid)} ₽ = {money(max(required_prepay-paid,0))} ₽"
    if ftype=='final':
        return f"Финальная оплата = остаток после оплаты: {money(max(total-paid,0))} ₽"
    return f"Активные заказы = полная сумма заказа: {money(total)} ₽"

def xml_escape(v):
    v='' if v is None else str(v)
    return v.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')

def col_letter(n):
    out=''
    while n:
        n,r=divmod(n-1,26)
        out=chr(65+r)+out
    return out

def make_simple_xlsx(path, sheet_name, rows):
    rows = rows or [[]]
    sheet_name = sheet_name[:31]
    max_cols=max([len(r) for r in rows]) if rows else 1
    row_xml=[]
    for ri,row in enumerate(rows,start=1):
        cells=[]
        for ci,val in enumerate(row,start=1):
            ref=col_letter(ci)+str(ri)
            if isinstance(val,(int,float)) and not isinstance(val,bool):
                cells.append('<c r="%s"><v>%s</v></c>'%(ref,val))
            else:
                cells.append('<c r="%s" t="inlineStr"><is><t>%s</t></is></c>'%(ref,xml_escape(val)))
        row_xml.append('<row r="%s">%s</row>'%(ri,''.join(cells)))
    cols=''.join(['<col min="%s" max="%s" width="24" customWidth="1"/>'%(i,i) for i in range(1,max_cols+1)])
    sheet_xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols>'+cols+'</cols><sheetData>'+''.join(row_xml)+'</sheetData></worksheet>'
    workbook_xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="'+xml_escape(sheet_name)+'" sheetId="1" r:id="rId1"/></sheets></workbook>'
    rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    wb_rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'
    styles='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs></styleSheet>'
    content='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml',content)
        z.writestr('_rels/.rels',rels)
        z.writestr('xl/workbook.xml',workbook_xml)
        z.writestr('xl/_rels/workbook.xml.rels',wb_rels)
        z.writestr('xl/styles.xml',styles)
        z.writestr('xl/worksheets/sheet1.xml',sheet_xml)

def safe_file_name(v):
    v=str(v or 'Без_названия')
    for ch in '<>:"/\\|?*':
        v=v.replace(ch,'_')
    return v[:80].strip() or 'Без_названия'

def order_stage_rows(con, oid):
    rows=[['Этап / звено','Описание','Ответственные / ФИО','Часы','Дата начала','Дата окончания','Цвет','ID этапа']]
    try:
        steps=con.execute("select * from production_steps where order_id=? order by sort_order,id",(oid,)).fetchall()
        for st in steps:
            rows.append([
                st['name'],
                st['description'] if 'description' in st.keys() else '',
                st['workers'] if 'workers' in st.keys() else '',
                st['duration_hours'],
                st['start_date'],
                st['end_date'],
                st['color'],
                st['id']
            ])
    except Exception:
        pass
    return rows

def order_main_rows(con, orders, ftype='all'):
    rows=[['№ заказа','Клиент','Телефон','Что делаем','Текущая стадия','Цена','Оплачено','Ждём предоплату','Ждём финальную оплату','Активная сумма','Готовность %','Дата входа','План окончания','Срочный','Причина отказа/заморозки']]
    for o in orders:
        try:
            pct=100 if ftype=='paid' or 'заверш' in str(o['current_stage']).lower() else (order_qty_percent(o) if 'order_qty_percent' in globals() else 0)
        except Exception:
            pct=0
        rows.append([
            o['order_number'],
            o['customer_name'],
            o['customer_phone'] if 'customer_phone' in o.keys() else '',
            o['short_description'],
            o['current_stage'],
            o['price_total'],
            o['paid_amount'] if 'paid_amount' in o.keys() else 0,
            finance_value_for_order(o,'prepay'),
            finance_value_for_order(o,'final'),
            finance_value_for_order(o,'active'),
            int(pct),
            o['planned_start'] if 'planned_start' in o.keys() else '',
            o['planned_finish'] if 'planned_finish' in o.keys() else '',
            'Да' if int(o['is_urgent'] or 0)==1 else 'Нет',
            ''
        ])
    return rows

def select_orders_for_export(con, ftype='all'):
    rows=con.execute("select * from orders order by id desc").fetchall()
    result=[]
    for o in rows:
        st=str(o['current_stage'] or '').lower()
        if ftype=='paid' and finance_value_for_order(o,'paid')<=0: continue
        if ftype=='prepay' and finance_value_for_order(o,'prepay')<=0: continue
        if ftype=='final' and finance_value_for_order(o,'final')<=0: continue
        if ftype=='active' and finance_value_for_order(o,'active')<=0: continue
        if ftype=='completed' and ('заверш' not in st): continue
        if ftype=='refused' and not any(x in st for x in ['отказ','заморож','отмен']): continue
        result.append(o)
    return result

def create_export_zip(ftype='all'):
    con=db()
    try:
        seed_daily_demo(con)
    except Exception:
        pass
    tmp=tempfile.mkdtemp(prefix='skwest_crm_export_')
    base=Path(tmp)
    label={
        'all':'Все_заказы',
        'paid':'Оплачено_клиентами',
        'prepay':'Ждем_предоплату',
        'final':'Ждем_финальную_оплату',
        'active':'Активные_заказы',
        'completed':'Выполненные_заказы',
        'refused':'Отказы_и_заморозки'
    }.get(ftype,'Все_заказы')
    month_dir=base/'2026'/'06_Июнь'
    month_dir.mkdir(parents=True,exist_ok=True)
    tpl=Path(__file__).parent/'templates'/'orders_template_2026.xlsx'
    if tpl.exists():
        shutil.copy2(tpl, month_dir/'00_Оригинальный_шаблон_без_изменений.xlsx')
    (month_dir/'ГДЕ_ЛЕЖИТ_ТАБЛИЦА.txt').write_text('Оригинальная таблица-шаблон лежит здесь: 00_Оригинальный_шаблон_без_изменений.xlsx\nНовые Excel-отчёты лежат рядом: 01, 02, 03, 04.\nПапки заказов находятся ниже по клиентам и номерам заказов.', encoding='utf-8')
    orders=select_orders_for_export(con,ftype)
    make_simple_xlsx(month_dir/('01_'+label+'.xlsx'),label,order_main_rows(con,orders,ftype))
    make_simple_xlsx(month_dir/'02_Все_заказы_для_аналитики.xlsx','Все заказы',order_main_rows(con,select_orders_for_export(con,'all'),'all'))
    make_simple_xlsx(month_dir/'03_Отказы_и_замороженные.xlsx','Отказы',order_main_rows(con,select_orders_for_export(con,'refused'),'refused'))
    make_simple_xlsx(month_dir/'04_Выполненные_заказы.xlsx','Выполненные',order_main_rows(con,select_orders_for_export(con,'completed'),'completed'))
    for o in orders:
        client_dir=month_dir/safe_file_name(o['customer_name'])
        order_dir=client_dir/(safe_file_name(o['order_number'])+'_'+safe_file_name(o['short_description']))
        order_dir.mkdir(parents=True,exist_ok=True)
        info=[
            'Номер заказа: '+str(o['order_number']),
            'Клиент: '+str(o['customer_name']),
            'Телефон: '+str(o['customer_phone'] if 'customer_phone' in o.keys() else ''),
            'Что делаем: '+str(o['short_description']),
            'Стадия: '+str(o['current_stage']),
            'Цена: '+str(o['price_total']),
            'Оплачено: '+str(o['paid_amount'] if 'paid_amount' in o.keys() else 0),
            'Ожидание предоплаты: '+str(finance_value_for_order(o,'prepay')),
            'Ожидание финальной оплаты: '+str(finance_value_for_order(o,'final')),
            'Дата входа: '+str(o['planned_start'] if 'planned_start' in o.keys() else ''),
            'План окончания: '+str(o['planned_finish'] if 'planned_finish' in o.keys() else ''),
            'Срочный: '+('Да' if int(o['is_urgent'] or 0)==1 else 'Нет')
        ]
        (order_dir/'01_order_info.txt').write_text('\n'.join(info),encoding='utf-8')
        make_simple_xlsx(order_dir/'02_этапы_звенья_ответственные.xlsx','Этапы',order_stage_rows(con,o['id']))
        (order_dir/'03_файлы_по_этапам.txt').write_text('Здесь на сервере будут договоры, счета, КП, эскизы, спецификации, DXF, PDF и остальные файлы по этапам заказа.',encoding='utf-8')
    zip_path=base/(label+'_2026_06.zip')
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in month_dir.rglob('*'):
            z.write(p,p.relative_to(base))
    con.close()
    return str(zip_path)


ORDER_TABLE_HEADERS = [
    '№ заказа','Дата заказа','Наименование изделия','Ед.изм','Общий объем','Срок заказа (кал. дни)',
    'Ответсвенный за проектирование','Срок проектирование (кал. дни)','Ответственный по цеху (за изготовление)','Срок изделия заказа (кал. дни)',
    'Лазерная резка','Срок по лазерной резке (кал. дни)','Гибка','Срок по гибке (кал. дни)','Сварка','Срок по сварке (кал. дни)',
    'Подготовка, зачистка','Срок по подготовке (кал. дни)','Покраска','Срок по покраске (кал. дни)','Сборка','Срок по сборке (кал. дни)',
    'Ответственный за монтаж','Срок по монтажу (кал. дни)','Ответственный за замеры','Дата замеров','Сумма заказа','Ответственный за выпуск документов','Аванс ','Остаток','Подпись','Примечание'
]

def order_table_template_path():
    return Path(__file__).parent / 'templates' / 'orders_template_2026.xlsx'

def date_only(v):
    return (str(v or '')[:10])

def days_between(a,b):
    try:
        da=datetime.strptime(str(a)[:10],'%Y-%m-%d')
        db=datetime.strptime(str(b)[:10],'%Y-%m-%d')
        return max((db-da).days,0)
    except Exception:
        return ''

def step_match_rows(con, oid, word):
    try:
        return con.execute("select * from production_steps where order_id=? and lower(name) like ? order by sort_order,id",(oid,'%'+word.lower()+'%')).fetchall()
    except Exception:
        return []

def step_worker_text(rows):
    names=[]
    for r in rows:
        w=''
        try: w=r['workers'] or ''
        except Exception: pass
        if w: names.append(w)
    return ', '.join(names) if names else 'нет'

def step_days(rows):
    total=0
    found=False
    for r in rows:
        try:
            total += float(r['duration_hours'] or 0)
            found=True
        except Exception: pass
    if not found: return 0
    return max(1, round(total/8,1))

def order_table_base_row(con, o):
    oid=o['id']
    start=date_only(o['planned_start'] if 'planned_start' in o.keys() else o['created_at'])
    finish=date_only(o['planned_finish'] if 'planned_finish' in o.keys() else '')
    laser=step_match_rows(con, oid, 'лазер')
    bend=step_match_rows(con, oid, 'гиб')
    weld=step_match_rows(con, oid, 'свар')
    prep=step_match_rows(con, oid, 'зач') + step_match_rows(con, oid, 'подготов')
    paint=step_match_rows(con, oid, 'покрас')
    assembly=step_match_rows(con, oid, 'сбор')
    production_days=sum([step_days(x) for x in [laser,bend,weld,prep,paint,assembly]])
    price=o['price_total'] if 'price_total' in o.keys() else 0
    paid=o['paid_amount'] if 'paid_amount' in o.keys() else 0
    remaining=o['remaining_amount'] if 'remaining_amount' in o.keys() else max(float(price or 0)-float(paid or 0),0)
    qty=o['total_items'] if 'total_items' in o.keys() else 1
    unit='шт'
    try:
        item=o['item_name'] or ''
        if 'м.п' in item or 'м.п.' in item: unit='м.п'
        elif 'кв' in item: unit='кв.м'
    except Exception: pass
    return [
        o['order_number'], start, o['short_description'], unit, qty, days_between(start,finish),
        'Дмитрий', 1, 'Потапов Д.Е.', production_days,
        step_worker_text(laser), step_days(laser), step_worker_text(bend), step_days(bend), step_worker_text(weld), step_days(weld),
        step_worker_text(prep), step_days(prep), step_worker_text(paint), step_days(paint), step_worker_text(assembly), step_days(assembly),
        'нет', 'нет', 'Коляда И.С.', '', price, 'Ипатова Ю.Н.', paid, remaining, '', o['current_stage']
    ]

def order_table_rows_for_display(con):
    try: seed_daily_demo(con)
    except Exception: pass
    orders=con.execute("select * from orders order by id").fetchall()
    rows=[]
    for o in orders:
        vals=order_table_base_row(con,o)
        overrides=con.execute("select col_index,value from order_table_overrides where order_id=?",(o['id'],)).fetchall()
        for ov in overrides:
            ci=int(ov['col_index'])
            if 0 <= ci < len(vals): vals[ci]=ov['value']
        rows.append((o,vals))
    return rows

def render_order_table(uid):
    con=db()
    rows=order_table_rows_for_display(con)
    con.close()
    header=''.join(['<th class="ot_col_%s">%s</th>'%(i,esc(h)) for i,h in enumerate(ORDER_TABLE_HEADERS)])
    body_rows=''
    for o,vals in rows:
        tds=''
        for i,v in enumerate(vals):
            cls='editable_cell'
            if i in (0,1,2,26,28,29,31): cls+=' important_cell'
            tds += '<td><input class="%s" name="cell_%s_%s" value="%s"></td>'%(cls,o['id'],i,esc(v))
        body_rows += '<tr>%s</tr>'%tds
    table=(
        '<form method="post" action="/save_order_table"><input type="hidden" name="user" value="%s">'
        '<div class="table_toolbar"><button class="btn green">Сохранить ручные правки</button>'
        '<a class="btn" href="/order_table_xlsx?user=%s">Скачать эту таблицу Excel</a>'
        '<a class="btn" href="/exports?user=%s">Архив ZIP</a></div>'
        '<div class="order_table_scroll"><table class="order_proto_table"><tr>%s</tr>%s</table></div></form>'
    )%(uid,uid,uid,header,body_rows)
    body=(
        '<div class="card"><h1>Таблица заказов</h1>'
        '<p class="muted">Это прототип той самой таблицы. Она заполняется автоматически из заказов, этапов производства, оплат и ответственных. Любую ячейку можно поправить вручную и сохранить.</p>'
        '<div class="template_hint"><b>Где лежит шаблон:</b><span>В программе: <code>crm_app/templates/orders_template_2026.xlsx</code></span><span>Скачивание: кнопка «Скачать эту таблицу Excel» выгружает этот же шаблон, но уже заполненный.</span></div>'
        '</div><div class="card"><h2>Заполнено сейчас</h2>'+table+'</div>'
    )
    return layout('Таблица заказов',body,uid)

def xlsx_col_name(n):
    s=''
    while n:
        n,r=divmod(n-1,26); s=chr(65+r)+s
    return s

def xlsx_xml_escape(v):
    v='' if v is None else str(v)
    return v.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')

def make_cell_xml(col,row,val,style=''):
    ref='%s%s'%(col,row)
    sval=(' s="%s"'%style) if style else ''
    try:
        # Keep IDs like CRM-1001 as text, only plain numbers as numeric
        if isinstance(val,(int,float)) and not isinstance(val,bool):
            return '<c r="%s"%s><v>%s</v></c>'%(ref,sval,val)
        if str(val).strip() and re.fullmatch(r'-?\d+(\.\d+)?', str(val).strip()) and col not in ('A','B','C','D','G','I','K','M','O','Q','S','U','W','Y','AB','AE','AF'):
            return '<c r="%s"%s><v>%s</v></c>'%(ref,sval,str(val).strip())
    except Exception:
        pass
    return '<c r="%s"%s t="inlineStr"><is><t>%s</t></is></c>'%(ref,sval,xlsx_xml_escape(val))

def filled_order_table_xlsx():
    con=db()
    rows=order_table_rows_for_display(con)
    con.close()
    src=order_table_template_path()
    tmpdir=Path(tempfile.mkdtemp(prefix='skwest_order_table_'))
    out=tmpdir/'Таблица_заказов_2026_заполненная.xlsx'
    with zipfile.ZipFile(src,'r') as zin:
        sheet=zin.read('xl/worksheets/sheet1.xml').decode('utf-8')
        styles={}
        mrow=re.search(r'<row[^>]* r="3"[^>]*>.*?</row>', sheet, flags=re.S)
        if mrow:
            for m in re.finditer(r'<c r="([A-Z]+)3"([^>]*)>', mrow.group(0)):
                sm=re.search(r' s="(\d+)"', m.group(2))
                styles[m.group(1)]=sm.group(1) if sm else ''
        data_rows=[]
        for r_idx,(_,vals) in enumerate(rows,start=3):
            cells=[]
            for c_idx,val in enumerate(vals,start=1):
                col=xlsx_col_name(c_idx)
                cells.append(make_cell_xml(col,r_idx,val,styles.get(col,'')))
            data_rows.append('<row r="%s">%s</row>'%(r_idx,''.join(cells)))
        # Remove old data rows from 3 onward but keep header rows 1-2
        sheet=re.sub(r'<row[^>]* r="([3-9]|[1-9]\d+)"[^>]*>.*?</row>','',sheet,flags=re.S)
        sheet=sheet.replace('</sheetData>',''.join(data_rows)+'</sheetData>')
        end_row=max(2,2+len(rows))
        sheet=re.sub(r'<dimension ref="[^"]+"/>','<dimension ref="A1:AF%s"/>'%end_row,sheet, count=1)
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                if item.filename=='xl/worksheets/sheet1.xml':
                    zout.writestr(item, sheet.encode('utf-8'))
                else:
                    zout.writestr(item, zin.read(item.filename))
    return str(out)


def render_exports_page(uid):
    cards=[('all','Все заказы','Полная выгрузка всех заказов'),('paid','Оплачено клиентами','Из каких заказов получились деньги в компании'),('prepay','Ждём предоплату','Заказы, которые ждут предоплату'),('final','Ждём финальную оплату','Остатки после выполнения'),('active','Активные заказы','Сумма в работе'),('completed','Выполненные','Выполненные заказы, этапы, сроки, ответственные'),('refused','Отказы / заморозки','Отказы и замороженные заказы для аналитики')]
    html=''
    for key,title,desc in cards:
        html += '<a class="export_card" href="/export_zip?type=%s&user=%s"><b>%s</b><span>%s</span></a>'%(key,uid,title,desc)
    body=('<div class="card"><h1>Архив и выгрузка заказов</h1><p class="muted">Скачивается ZIP. Внутри: Excel-таблицы, папки по клиентам и заказам, этапы, звенья, ответственные и место под файлы.</p>'+export_location_hint()+'<div class="export_grid">'+html+'</div><div class="readonly">Оригинальный шаблон Excel не меняется. Он нужен как эталон. Новые отчёты создаются отдельно рядом с ним.</div></div>')
    return layout('Архив заказов',body,uid)


def render_timer_page(uid):
    con=db()
    try:
        seed_daily_demo(con)
    except Exception:
        pass
    rows=con.execute("select * from orders where current_stage<>'Заказ завершён' order by planned_finish,id").fetchall()
    cards=''
    today=datetime.strptime('2026-06-03','%Y-%m-%d').date()
    for o in rows:
        finish_txt=get_col(o,'planned_finish','') or ''
        try:
            finish=datetime.strptime(finish_txt[:10],'%Y-%m-%d').date()
            left=(finish-today).days
        except Exception:
            left='не указан'
        try:
            pct=100 if 'заверш' in str(o['current_stage']).lower() else (order_qty_percent(o) if 'order_qty_percent' in globals() else 0)
        except Exception:
            pct=0
        cards += (
            '<a class="timer_card" href="/chain?id=%s&user=%s"><b>%s</b><span>%s</span>'
            '<strong>%s</strong><small>до срока: %s дней</small><div class="bar"><i style="width:%s%%"></i></div><em>%s%%</em></a>'
        ) % (o['id'],uid,esc(o['order_number']),esc(o['customer_name']),esc(finish_txt or 'срок не указан'),left,int(pct),int(pct))
    if not cards:
        cards='<div class="readonly">Нет активных заказов.</div>'
    con.close()
    return layout('Таймер производства','<div class="card"><h1>Таймер производства</h1><p class="muted">Сроки заказов и процент готовности.</p><div class="timer_grid">'+cards+'</div></div>',uid)


def status_badge_html(status):
    st=str(status or '')
    low=st.lower()
    cls='status_new'
    if 'оплат' in low:
        cls='status_pay'
    if 'производ' in low or 'изготов' in low:
        cls='status_work'
    if 'соглас' in low:
        cls='status_agree'
    if 'заверш' in low or 'готов' in low:
        cls='status_done'
    if 'отказ' in low or 'заморож' in low or 'отмен' in low:
        cls='status_bad'
    return '<span class="status_badge %s">%s</span>' % (cls, esc(st))

def export_location_hint():
    return (
        '<div class="template_hint">'
        '<b>Где находится твоя таблица:</b>'
        '<span>Внутри программы: <code>crm_app/templates/orders_template_2026.xlsx</code></span>'
        '<span>Внутри скачанного ZIP: <code>2026/06_Июнь/00_Оригинальный_шаблон_без_изменений.xlsx</code></span>'
        '<span>Эта таблица лежит как оригинал и не меняется. Рядом создаются новые Excel-отчёты.</span>'
        '</div>'
    )


def render_finance_page(uid, ftype):
    titles={'paid':'Оплачено клиентами','prepay':'Ждём предоплату','final':'Ждём финальную оплату','active':'Активные заказы'}
    color_map={'paid':'finance_green','prepay':'finance_yellow','final':'finance_red','active':'finance_blue'}
    con=db()
    try:
        seed_daily_demo(con)
    except Exception:
        pass
    orders=con.execute("select * from orders order by id desc").fetchall()
    selected=[]; total_sum=0
    for o in orders:
        val=finance_value_for_order(o, ftype)
        if val>0:
            selected.append((o,val)); total_sum+=val
    rows=''
    for o,val in selected:
        price=o['price_total'] if 'price_total' in o.keys() else (o['total_amount'] if 'total_amount' in o.keys() else 0)
        try:
            pct=100 if ftype=='paid' or 'заверш' in str(o['current_stage']).lower() else (order_qty_percent(o) if 'order_qty_percent' in globals() else 0)
        except Exception:
            pct=0
        rows += (
            '<a class="finance_order_row %s" href="/chain?id=%s&user=%s">'
            '<div><b>%s</b><small>%s</small></div><div>%s</div>'
            '<div><strong>%s ₽</strong><small>цена</small></div>'
            '<div><strong>%s ₽</strong><small>в этом разделе</small></div>'
            '<div><span class="progress_pill">%s%%</span><small>%s</small></div></a>'
        ) % (color_map.get(ftype,'finance_blue'),o['id'],uid,esc(o['order_number']),esc(o['customer_name']),status_badge_html(o['current_stage']),money(price),money(val),100 if ftype=='paid' or 'заверш' in str(o['current_stage']).lower() else int(pct),esc((o['planned_finish'] if 'planned_finish' in o.keys() else '') or 'срок не указан'))
    if not rows:
        rows='<div class="readonly">Нет заказов в этом разделе</div>'
    body=(
        '<div class="card"><h1>%s</h1><div class="finance_big_sum %s">%s ₽</div>'
        '<p class="muted">Ниже показано, из каких заказов собралась эта сумма.</p>'
        '<a class="btn green" href="/export_zip?type=%s&user=%s">Скачать ZIP / Excel по этому разделу</a>%s</div>'
        '<div class="card"><h2>Заказы в этом разделе</h2><div class="finance_order_list">%s</div></div>'
    ) % (esc(titles.get(ftype,'Финансы')), color_map.get(ftype,'finance_blue'), money(total_sum), ftype, uid, export_location_hint(), rows)
    con.close()
    return layout(titles.get(ftype,'Финансы'),body,uid)


def render_orders_page(uid):
    con=db()
    try:
        seed_daily_demo(con)
    except Exception:
        pass
    rows=con.execute("select * from orders where current_stage<>'Заказ завершён' order by id desc").fetchall()
    html_rows=''
    for o in rows:
        price=get_col(o,'price_total',get_col(o,'total_amount',0))
        urgent = '<span class="urgent_small">🔥 Срочный</span>' if int(o['is_urgent'] or 0)==1 else ''
        html_rows += (
            '<a class="order_list_card" href="/chain?id=%s&user=%s">'
            '<div><b>%s - %s</b> %s<small>%s</small></div>'
            '<div><span class="pill">%s</span><strong>%s ₽</strong></div>'
            '</a>'
        ) % (o['id'],uid,esc(o['order_number']),esc(o['customer_name']),urgent,esc(o['short_description']),esc(o['current_stage']),money(price))
    con.close()
    body = '<div class="card"><h1>Активные заказы</h1><p class="muted">Здесь все заказы, которые сейчас не завершены.</p><div class="order_list">' + (html_rows or '<div class="readonly">Активных заказов нет.</div>') + '</div></div>'
    return layout('Активные заказы', body, uid)


def render_production_page(uid):
    con=db()
    try:
        prod=today_production_html(con,uid)
    except Exception:
        prod='<div class="readonly">Производство пока не настроено. Данил должен назначить звенья на заказ.</div>'
    con.close()
    body = (
        '<div class="card"><h1>Производство и таймер</h1>'
        '<p class="muted">Здесь видно, что сейчас в работе.</p>'
        '<a class="btn blue" href="/timer?user=%s">Открыть таймер производства</a></div>'
        '<div class="card"><h2>Что сейчас в производстве</h2>' + prod + '</div>'
    ) % uid
    return layout('Производство', body, uid)


def order_color_class(order_id):
    try:
        return ORDER_COLOR_CLASSES[(int(order_id)-1) % len(ORDER_COLOR_CLASSES)]
    except Exception:
        return 'oc1'

def user_color_class(uid):
    try:
        return USER_COLOR_CLASSES.get(int(uid),'uc0')
    except Exception:
        return 'uc0'


def can_edit_production(uid):
    try:
        return get_user(int(uid))['role'] in ('workshop','shop_head')
    except Exception:
        return False

def can_assign_tasks(uid):
    try:
        return get_user(int(uid))['role'] in ('head_manager','director')
    except Exception:
        return False

def user_name_by_id(uid):
    try:
        con=db()
        u=con.execute("select * from users where id=?",(int(uid),)).fetchone()
        con.close()
        return u['name'] if u else 'Не назначен'
    except Exception:
        return 'Не назначен'



def order_deadline_reminders_html(uid):
    con=db()
    seed_daily_demo(con)
    # Тестовая текущая дата для демо календаря.
    today=datetime.strptime('2026-06-03','%Y-%m-%d').date()
    rows=con.execute("select * from orders where current_stage<>'Заказ завершён' and planned_finish is not null and planned_finish<>'' order by planned_finish,id").fetchall()
    items=''
    for o in rows:
        try:
            finish=datetime.strptime((o['planned_finish'] or '')[:10],'%Y-%m-%d').date()
            left=(finish-today).days
        except Exception:
            continue
        if left in (3,2,1):
            cls='rem3' if left==3 else ('rem2' if left==2 else 'rem1')
            items += (
                f'<a class="deadline_notice {cls}" href="/chain?id={o["id"]}&user={uid}">'
                f'<b>{left} дн. до срока</b>'
                f'<span>{esc(o["order_number"])} - {esc(o["customer_name"])}</span>'
                f'<small>Плановое завершение: {esc(o["planned_finish"])}</small>'
                f'</a>'
            )
    con.close()
    if not items:
        return '<div class="readonly">Сейчас нет заказов, которые подходят к сроку за 3/2/1 день.</div>'
    return '<div class="deadline_list">'+items+'</div>'



TEAM_COLORS=['#2563eb','#16a34a','#f97316','#9333ea','#dc2626','#0891b2','#ca8a04','#be185d','#0f766e','#7c3aed']

def seed_workshop_demo(con):
    cnt=con.execute("select count(*) c from workshop_workers").fetchone()['c']
    if cnt==0:
        workers=[
            ('Алексей Сварщик','Сварщик',''),
            ('Олег Покраска','Маляр',''),
            ('Павел Гибка','Оператор листогиба',''),
            ('Николай Лазер','Оператор лазера',''),
            ('Игорь Сборка','Сборщик','')
        ]
        for w in workers:
            con.execute("insert into workshop_workers(full_name,position,phone,is_active,created_at) values(?,?,?,?,?)",(w[0],w[1],w[2],1,now_sql()))
    cnt=con.execute("select count(*) c from workshop_teams").fetchone()['c']
    if cnt==0:
        teams=[
            ('Звено 1 - лазер и гибка','Резка и гибка деталей','#2563eb',[3,4]),
            ('Звено 2 - сварка','Сварочные работы','#16a34a',[1]),
            ('Звено 3 - покраска','Порошковая покраска','#f97316',[2]),
            ('Звено 4 - сборка','Сборка и контроль','#9333ea',[5])
        ]
        for name,desc,color,members in teams:
            cur=con.execute("insert into workshop_teams(name,description,color,is_active,created_at) values(?,?,?,?,?)",(name,desc,color,1,now_sql()))
            tid=cur.lastrowid
            for wid in members:
                con.execute("insert into workshop_team_members(team_id,worker_id) values(?,?)",(tid,wid))
    con.commit()

def team_members_text(con, team_id):
    if not team_id:
        return ''
    rows=con.execute("""select w.full_name,w.position from workshop_team_members tm
        left join workshop_workers w on w.id=tm.worker_id where tm.team_id=? order by w.full_name""",(team_id,)).fetchall()
    return ', '.join([r['full_name']+' - '+(r['position'] or '') for r in rows if r['full_name']])

def team_select_options(con, selected=None):
    rows=con.execute("select * from workshop_teams where is_active=1 order by id").fetchall()
    html='<option value="">Не назначено</option>'
    for t in rows:
        sel=' selected' if str(selected or '')==str(t['id']) else ''
        html += '<option value="%s"%s>%s</option>' % (t['id'],sel,esc(t['name']))
    return html


def get_col(row, name, default=''):
    try:
        return row[name]
    except Exception:
        return default

def workshop_can(uid):
    try:
        u=get_user(int(uid))
        name=str(u['name'] or '').lower()
        title=str(u['title'] or '').lower()
        role=str(u['role'] or '').lower()
        return (
            role in ('workshop','production','chief_workshop','ceh','shop')
            or 'данил' in name
            or 'потапов' in name
            or 'начальник цеха' in title
            or 'цех' in title
        )
    except Exception:
        return False

def is_workshop_user(uid):
    return workshop_can(uid)

def ensure_workshop_tables(con):
    con.execute('''CREATE TABLE IF NOT EXISTS workshop_workers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        position TEXT,
        phone TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS workshop_teams(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        color TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS workshop_team_members(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER,
        worker_id INTEGER
    )''')
    try:
        con.execute('alter table production_steps add column team_id INTEGER')
    except Exception:
        pass
    try:
        con.execute('alter table production_steps add column assigned_date TEXT')
    except Exception:
        pass
    try:
        con.execute('alter table production_steps add column manual_locked INTEGER DEFAULT 1')
    except Exception:
        pass
    con.commit()

def seed_workshop_demo(con):
    ensure_workshop_tables(con)
    cnt=con.execute("select count(*) c from workshop_workers").fetchone()['c']
    if cnt==0:
        for full_name,position in [('Алексей Петров','Сварщик'),('Олег Смирнов','Маляр'),('Павел Козлов','Оператор листогиба'),('Николай Егоров','Оператор лазера'),('Игорь Орлов','Сборщик')]:
            con.execute("insert into workshop_workers(full_name,position,phone,is_active,created_at) values(?,?,?,?,?)",(full_name,position,'',1,now_sql()))
    cnt=con.execute("select count(*) c from workshop_teams").fetchone()['c']
    if cnt==0:
        base=[('Звено 001','Лазер и гибка','#2563eb',[3,4]),('Звено 002','Сварка','#16a34a',[1]),('Звено 003','Покраска','#f97316',[2]),('Звено 004','Сборка','#9333ea',[5])]
        for name,desc,color,members in base:
            cur=con.execute("insert into workshop_teams(name,description,color,is_active,created_at) values(?,?,?,?,?)",(name,desc,color,1,now_sql()))
            tid=cur.lastrowid
            for wid in members:
                con.execute("insert into workshop_team_members(team_id,worker_id) values(?,?)",(tid,wid))
    con.commit()

def team_members_text(con, team_id):
    if not team_id:
        return ''
    ensure_workshop_tables(con)
    rows=con.execute('''select w.full_name,w.position from workshop_team_members tm
        left join workshop_workers w on w.id=tm.worker_id
        where tm.team_id=? and coalesce(w.is_active,1)=1 order by w.full_name''',(team_id,)).fetchall()
    return ', '.join([r['full_name']+' - '+(r['position'] or '') for r in rows if r['full_name']])

def team_select_options(con, selected=None):
    ensure_workshop_tables(con)
    rows=con.execute("select * from workshop_teams where is_active=1 order by id").fetchall()
    html='<option value="">Не назначено</option>'
    for t in rows:
        sel=' selected' if str(selected or '')==str(t['id']) else ''
        html += '<option value="%s"%s>№%03d / %s / %s</option>' % (t['id'],sel,t['id'],esc(t['name']),esc(t['description'] or ''))
    return html



def render_access_check(uid):
    u=get_user(int(uid))
    body=(
        '<div class="card"><h1>Проверка доступа</h1>'
        '<p class="muted">Эта страница показывает, почему аккаунту разрешён или запрещён доступ к базе рабочих.</p>'
        '<table><tr><th>Поле</th><th>Значение</th></tr>'
        '<tr><td>Имя</td><td>%s</td></tr>'
        '<tr><td>Должность</td><td>%s</td></tr>'
        '<tr><td>Роль</td><td>%s</td></tr>'
        '<tr><td>Доступ Данила к цеху</td><td><b>%s</b></td></tr>'
        '</table>'
        '<a class="btn green" href="/workers?user=%s">Работники цеха</a> '
        '<a class="btn blue" href="/teams?user=%s">Звенья</a>'
        '</div>'
    ) % (esc(u['name']),esc(u['title']),esc(u['role']),'РАЗРЕШЁН' if workshop_can(uid) else 'ЗАПРЕЩЁН',uid,uid)
    return layout('Проверка доступа',body,uid)


def render_workshop_workers(uid):
    if not workshop_can(uid):
        return layout('Нет доступа','<div class="card">Базу работников цеха редактирует только Данил Потапов.</div>',uid)
    con=db()
    seed_workshop_demo(con)
    workers=con.execute("select * from workshop_workers where is_active=1 order by id").fetchall()
    rows=''
    for w in workers:
        rows += '<tr><td>%s</td><td>%s</td><td><a class="btn danger smallbtn" href="/delete_worker?id=%s&user=%s">Удалить</a></td></tr>' % (esc(w['full_name']),esc(w['position']),w['id'],uid)
    body = (
        '<div class="card"><h1>Работники цеха</h1><p class="muted">Телефон убран. Данил ведёт только ФИО и должность.</p>'
        '<form class="inline_form workers_form" method="post" action="/add_worker"><input type="hidden" name="user" value="%s">'
        '<input name="full_name" placeholder="ФИО сотрудника" required><input name="position" placeholder="Должность: сварщик, маляр, лазерщик"><button class="btn green">Добавить</button></form></div>' % uid
        + '<div class="card"><h2>Список работников</h2><table><tr><th>ФИО</th><th>Должность</th><th></th></tr>%s</table></div>' % (rows or '<tr><td colspan="3">Работников пока нет</td></tr>')
    )
    con.close()
    return layout('Работники цеха',body,uid)


def render_workshop_teams(uid):
    if not workshop_can(uid):
        return layout('Нет доступа','<div class="card">Звенья цеха редактирует только Данил Потапов.</div>',uid)
    con=db()
    seed_workshop_demo(con)
    teams=con.execute("select * from workshop_teams where is_active=1 order by id").fetchall()
    workers=con.execute("select * from workshop_workers where is_active=1 order by full_name").fetchall()
    worker_opts=''.join(['<option value="%s">%s - %s</option>'%(w['id'],esc(w['full_name']),esc(w['position'])) for w in workers])
    cards=''
    for t in teams:
        members=team_members_text(con,t['id'])
        cards += (
            '<div class="team_card" style="border-color:%s"><div><b>№%03d — %s</b><small>%s</small><span>%s</span></div>'
            '<div class="team_actions"><a class="btn blue smallbtn" href="/edit_team?id=%s&user=%s">Редактировать</a><a class="btn danger smallbtn" href="/delete_team?id=%s&user=%s">Удалить</a></div></div>'
        ) % (esc(t['color'] or '#2563eb'),t['id'],esc(t['name']),esc(t['description'] or 'Назначение не указано'),esc(members or 'Сотрудники не выбраны'),t['id'],uid,t['id'],uid)
    body = (
        '<div class="card"><h1>Звенья производства</h1><p class="muted">Данил создаёт звенья с уникальным номером. В звено можно собрать любое количество сотрудников.</p>'
        '<form class="formgrid" method="post" action="/add_team"><input type="hidden" name="user" value="%s">'
        '<label>Название звена<input name="name" required placeholder="Например: Покраска / Сварка / Лазер"></label>'
        '<label>Назначение звена<input name="description" placeholder="Что делает это звено"></label>'
        '<label>Цвет<input name="color" type="color" value="#2563eb"></label>'
        '<label>Сотрудники<select name="workers" multiple size="7">%s</select></label>'
        '<button class="btn green">Создать звено</button></form></div>' % (uid,worker_opts)
        + '<div class="card"><h2>Каталог звеньев</h2><div class="team_grid">%s</div></div>' % (cards or '<div class="readonly">Звеньев пока нет</div>')
    )
    con.close()
    return layout('Звенья производства',body,uid)

def render_edit_team(uid, tid):
    if not workshop_can(uid):
        return layout('Нет доступа','<div class="card">Редактировать звенья может только Данил.</div>',uid)
    con=db()
    seed_workshop_demo(con)
    t=con.execute("select * from workshop_teams where id=?",(tid,)).fetchone()
    if not t:
        con.close(); return layout('Звено не найдено','<div class="card">Звено не найдено.</div>',uid)
    selected=[str(x['worker_id']) for x in con.execute("select worker_id from workshop_team_members where team_id=?",(tid,)).fetchall()]
    workers=con.execute("select * from workshop_workers where is_active=1 order by full_name").fetchall()
    opts=''
    for w in workers:
        sel=' selected' if str(w['id']) in selected else ''
        opts+='<option value="%s"%s>%s - %s</option>'%(w['id'],sel,esc(w['full_name']),esc(w['position']))
    body=(
        '<div class="card"><h1>Редактировать звено №%03d</h1>'
        '<form class="formgrid" method="post" action="/update_team"><input type="hidden" name="user" value="%s"><input type="hidden" name="team_id" value="%s">'
        '<label>Название<input name="name" value="%s" required></label>'
        '<label>Назначение<input name="description" value="%s"></label>'
        '<label>Цвет<input name="color" type="color" value="%s"></label>'
        '<label>Сотрудники<select name="workers" multiple size="8">%s</select></label>'
        '<button class="btn green">Сохранить звено</button></form></div>'
    ) % (tid,uid,tid,esc(t['name']),esc(t['description'] or ''),esc(t['color'] or '#2563eb'),opts)
    con.close()
    return layout('Редактировать звено',body,uid)


def render_assign_production(uid, oid):
    if not is_workshop_user(uid):
        return layout('Нет доступа','<div class="card">Назначать звенья может только Данил Потапов.</div>',uid)
    con=db()
    seed_workshop_demo(con)
    o=con.execute("select * from orders where id=?",(oid,)).fetchone()
    if not o:
        con.close()
        return layout('Заказ не найден','<div class="card">Заказ не найден.</div>',uid)
    steps=con.execute("select * from production_steps where order_id=? order by sort_order,id",(oid,)).fetchall()
    if not steps:
        demo=[('Лазерная резка',6),('Листогиб деталей',8),('Сварка',10),('Покраска',7),('Сборка и контроль',5)]
        for i,(name,hours) in enumerate(demo,1):
            con.execute("insert into production_steps(order_id,name,description,duration_hours,start_date,end_date,color,sort_order,workers,team_id,assigned_date,manual_locked) values(?,?,?,?,?,?,?,?,?,?,?,?)",
                (oid,name,'',hours,'','',TEAM_COLORS[i%len(TEAM_COLORS)],i,'',None,'',1))
        con.commit()
        steps=con.execute("select * from production_steps where order_id=? order by sort_order,id",(oid,)).fetchall()
    rows=''
    for st in steps:
        rows += (
            '<tr><td><input name="name_%s" value="%s"></td>'
            '<td><select name="team_%s">%s</select></td>'
            '<td><input type="date" name="date_%s" value="%s"></td>'
            '<td><input type="time" name="time_%s" value="%s"></td>'
            '<td><input type="number" step="0.5" name="hours_%s" value="%s"></td></tr>'
        ) % (
            st['id'],esc(st['name']),
            st['id'],team_select_options(con,st['team_id'] if 'team_id' in st.keys() else None),
            st['id'],esc((st['assigned_date'] or st['start_date'] or '')[:10] if 'assigned_date' in st.keys() else (st['start_date'] or '')[:10]),
            st['id'],esc(((st['start_date'] or '09:00')[-5:] if st['start_date'] else '09:00')),
            st['id'],esc(st['duration_hours'] or 1)
        )
    body = (
        '<div class="card"><h1>Назначить звенья на заказ</h1><p class="muted">%s - %s</p>'
        '<div class="readonly">После сохранения эти этапы появятся в производственном календаре. Автоматических сдвигов нет.</div></div>' % (esc(o['order_number']),esc(o['customer_name']))
        + '<div class="card"><form method="post" action="/save_production_assignment"><input type="hidden" name="user" value="%s"><input type="hidden" name="order_id" value="%s">'
        '<table><tr><th>Этап</th><th>Звено</th><th>Дата</th><th>Время</th><th>Часы</th></tr>%s</table>'
        '<button class="btn green">Сохранить в календарь производства</button></form></div>' % (uid,oid,rows)
    )
    con.close()
    return layout('Назначить звенья',body,uid)


def render_orders_calendar(uid):
    con=db()
    seed_daily_demo(con)
    orders=con.execute("select * from orders where current_stage<>'Заказ завершён' order by planned_start,id").fetchall()
    year,month=2026,6
    by_day={}
    for o in orders:
        pairs=[('Зашёл',(o['planned_start'] or '')[:10],'start'),('Финиш',(o['planned_finish'] or '')[:10],'finish')]
        for label,day,kind in pairs:
            if day:
                by_day.setdefault(day,[]).append((o,label,kind))
    cells=[]
    for d in month_calendar_days(year,month):
        if d is None:
            cells.append('<div class="order_day empty"></div>')
            continue
        key=f'{year}-{month:02d}-{d:02d}'
        items=''
        for o,label,kind in by_day.get(key,[]):
            color=order_color_class(o['id'])
            urgent_cls = ' urgent_order' if int(o['is_urgent'] or 0)==1 else ''
            fire_class = 'active' if int(o['is_urgent'] or 0)==1 else ''
            fire_btn = f'<button type="button" class="fire_toggle {fire_class}" data-orderid="{o["id"]}" title="Срочный заказ">🔥</button>' if can_assign_tasks(uid) or int(o['is_urgent'] or 0)==1 else ''
            items += (
                f'<a class="order_short {kind} {color}{urgent_cls}" data-order-id="{o["id"]}" href="/chain?id={o["id"]}&user={uid}">'
                f'<div class="order_fire_top">{fire_btn}</div>'
                f'<b>{esc(label)}</b>'
                f'<span>{esc(o["order_number"])}</span>'
                f'<small>{esc(o["customer_name"])}</small>'
                f'<em>{esc(o["current_stage"])}</em>'
                f'</a>'
            )
        empty='<span class=muted>Нет заказов</span>'
        cells.append(f'<div class="order_day"><b>{d} Июнь</b>{items or empty}</div>')
    con.close()
    body=(
        '<div class="card"><h1>Календарь заказов</h1>'
        '<p class="muted">Простой календарь менеджера: когда заказ зашёл и когда должен закончиться. Каждый заказ выделен своим цветом. Наведи на начало или конец заказа — вторая точка этого же заказа начнёт прыгать.</p>'
        '<div class="order_color_legend"><span class="legend_start">Зашёл</span><span class="legend_finish">Финиш</span><span>Цвет = конкретный заказ</span></div>'
        '<h2>Напоминания по срокам</h2>'+order_deadline_reminders_html(uid)+'</div>'
        '<div class="card"><div class="weekheads"><b>Пн</b><b>Вт</b><b>Ср</b><b>Чт</b><b>Пт</b><b>Сб</b><b>Вс</b></div>'
        '<div class="orders_calendar">'+''.join(cells)+'</div></div>'
    )
    return layout('Календарь заказов',body,uid)


def render_daily_tasks_calendar(uid):
    con=db()
    seed_daily_demo(con)
    if can_assign_tasks(uid):
        rows=con.execute("select dt.*,o.order_number,o.is_urgent from daily_tasks dt left join orders o on o.id=dt.order_id order by dt.task_date,dt.id").fetchall()
        scope_text='Юлия и Сергей видят задачи всех сотрудников и ставят задачи через плюсик на нужный день.'
    else:
        rows=con.execute("select dt.*,o.order_number,o.is_urgent from daily_tasks dt left join orders o on o.id=dt.order_id where dt.assigned_to=? order by dt.task_date,dt.id",(uid,)).fetchall()
        scope_text='Вы видите только свои задачи. Редактировать и назначать задачи могут только Юлия или Сергей.'
    by_day={}
    for t in rows:
        by_day.setdefault((t['task_date'] or '')[:10],[]).append(t)
    today_key='2026-06-03'
    today_rows=by_day.get(today_key,[])
    remind=''
    if today_rows:
        remind='<div class="morning_reminder"><b>🔔 Напоминание на 8:00</b><span>Сегодня у вас задач: %s</span></div>' % len(today_rows)
    cells=[]
    for d in month_calendar_days(2026,6):
        if d is None:
            cells.append('<div class="task_day empty"></div>')
            continue
        key=f'2026-06-{d:02d}'
        plus = f'<a class="day_plus" href="/new_task?date={key}&user={uid}">+</a>' if can_assign_tasks(uid) else ''
        items=''
        for t in by_day.get(key,[]):
            cls=task_status_class(t['status'])
            urgent=' urgent_task' if t['priority']=='Срочная' else ''
            ucls=user_color_class(t['assigned_to'])
            order_urgent = int(t['is_urgent'] or 0)==1 if t['is_urgent'] is not None else False
            fire_class = 'active' if order_urgent else ''
            fire_btn = f'<button type="button" class="fire_toggle {fire_class}" data-orderid="{t["order_id"]}" title="Срочный заказ">🔥</button>' if t['order_id'] and (can_assign_tasks(uid) or order_urgent) else ''
            urgent_order_cls = ' urgent_order' if order_urgent else ''
            items += (
                f'<a class="daily_task {cls}{urgent} {ucls}{urgent_order_cls}" href="/task?id={t["id"]}&user={uid}">'
                f'<div class="task_fire_top">{fire_btn}</div>'
                f'<b>{esc(t["title"])}</b>'
                f'<span>{esc(user_name_by_id(t["assigned_to"]))}</span>'
                f'<small>{esc(t["status"])} - {esc(t["order_number"] or "Без заказа")}</small>'
                f'</a>'
            )
        empty='<span class=muted>Нет задач</span>'
        cells.append(f'<div class="task_day"><div class="day_head"><b>{d} Июнь</b>{plus}</div>{items or empty}</div>')
    con.close()
    body=(
        '<div class="card"><h1>Календарь задач</h1>'
        f'<p class="muted">{scope_text}</p>'
        f'{remind}'
        '<div class="task_legend"><span class="uc1">Иван</span><span class="uc2">Юлия</span><span class="uc3">Дмитрий</span><span class="uc4">Данил</span><span class="uc5">Сергей</span></div>'
        '</div>'
        '<div class="card"><div class="weekheads"><b>Пн</b><b>Вт</b><b>Ср</b><b>Чт</b><b>Пт</b><b>Сб</b><b>Вс</b></div>'
        '<div class="tasks_calendar">'+''.join(cells)+'</div></div>'
    )
    return layout('Календарь задач',body,uid)

def render_task_detail(uid, tid):
    con=db()
    t=con.execute("select dt.*,o.order_number from daily_tasks dt left join orders o on o.id=dt.order_id where dt.id=?",(tid,)).fetchone()
    if not t:
        con.close()
        return layout('Задача','<div class="card">Задача не найдена</div>',uid)
    body=f'''<div class="card"><h1>{esc(t['title'])}</h1><p class="muted">{esc(t['description'])}</p>
    <div class="grid"><div class="stat"><span>Дата</span><b>{esc(t['task_date'])}</b></div>
    <div class="stat"><span>Исполнитель</span><b>{esc(user_name_by_id(t['assigned_to']))}</b></div>
    <div class="stat"><span>Статус</span><b>{esc(t['status'])}</b></div>
    <div class="stat"><span>Заказ</span><b>{esc(t['order_number'] or 'Без заказа')}</b></div></div></div>'''
    con.close()
    return layout('Задача',body,uid)


def render_new_task(uid):
    if not can_assign_tasks(uid):
        return layout('Нет доступа','<div class="card">Нет прав создавать задачи.</div>',uid)
    con=db()
    users=con.execute("select * from users order by id").fetchall()
    orders=con.execute("select * from orders order by id desc").fetchall()
    user_opts=''.join([f'<option value="{u["id"]}">{esc(u["name"])} — {esc(u["title"])}</option>' for u in users])
    order_opts='<option value="">Без заказа</option>'+''.join([f'<option value="{o["id"]}">{esc(o["order_number"])} - {esc(o["customer_name"])}</option>' for o in orders])
    con.close()
    body=(
        '<div class="card"><h1>Центр постановки задач</h1>'
        '<p class="muted">Юлия или Сергей ставит задачи конкретному человеку на сегодня, завтра или любой день недели.</p>'
        '<form method="post" action="/create_daily_task" class="formgrid">'
        f'<input type="hidden" name="user" value="{uid}">'
        '<label>Название задачи<input name="title" required placeholder="Например: отвезти краску"></label>'
        '<label>Дата<input type="date" name="task_date" required value="2026-06-03"></label>'
        f'<label>Кому задача<select name="assigned_to">{user_opts}</select></label>'
        f'<label>Привязать к заказу<select name="order_id">{order_opts}</select></label>'
        '<label>Приоритет<select name="priority"><option>Обычная</option><option>Срочная</option></select></label>'
        '<label>Описание<textarea name="description" placeholder="Что нужно сделать коротко и понятно"></textarea></label>'
        '<button class="btn green">Поставить задачу</button>'
        '</form></div>'
    )
    return layout('Создать задачу',body,uid)

def calendar_can_drag(uid):
    return workshop_can(uid)

def render_calendar(uid):
    con=db(); can=can_edit_calendar(uid)
    rows=con.execute("""select ps.*,o.order_number,o.customer_name,o.short_description,o.is_urgent,o.id order_id,group_concat(w.full_name, ', ') workers from production_steps ps join orders o on o.id=ps.order_id left join step_workers sw on sw.step_id=ps.id left join workers w on w.id=sw.worker_id where o.current_stage='Изготовление заказа' group by ps.id order by ps.start_date,ps.sort_order""").fetchall()
    by_day={}
    for r in rows:
        try: by_day.setdefault(datetime.strptime(r['start_date'][:16],'%Y-%m-%d %H:%M').day,[]).append(r)
        except Exception: pass
    year,month=2026,6; import calendar as cal; first,days=cal.monthrange(year,month); cells=[]
    for w in ['Пн','Вт','Ср','Чт','Пт','Сб','Вс']: cells.append(f'<div class="day" style="min-height:auto;background:#111926"><b>{w}</b></div>')
    for _ in range(first): cells.append('<div class="day" style="opacity:.25;min-height:80px"></div>')
    seen=[]; legend=[]
    for r in rows:
        if r['order_number'] not in seen:
            seen.append(r['order_number']); legend.append(f'<span class="orderlegendchip"><i style="background:{order_color(r["order_number"])}"></i>{esc(r["order_number"])}</span>')
    for d in range(1,days+1):
        dt=datetime(year,month,d); weekend=dt.weekday()>=5; holiday=(d==12); short=(d==11); cls='holiday' if holiday else 'weekend' if weekend else 'short' if short else 'work'; schedule='Выходной: День России' if holiday else 'Выходной' if weekend else '09:00–17:00 - сокращенный день' if short else '09:00–18:00'; blocks=''
        for r in by_day.get(d,[]):
            col=order_color(r['order_number']); urgent=bool(r['is_urgent']); urgent_cls=' urgent_order' if urgent else ''; fire=f'<button type="button" draggable="false" class="fire_toggle {"active" if urgent else ""}" data-orderid="{r["order_id"]}" title="Срочный заказ">🔥</button>' if can else ''; drag_attrs=f'draggable="true" data-step="{r["id"]}"' if can else f'data-step="{r["id"]}"'; hint='Перенести вручную' if can else 'Только просмотр'
            blocks += (
                '<div class="orderblock%s draggable_task" %s style="border-color:%s;background:linear-gradient(180deg,%s55,#0b1320)">' % (urgent_cls, drag_attrs, col, col)
                + '<div class="calendar_card_top">%s</div>' % fire
                + '<b>%s - %s</b><br>' % (esc(r['order_number']), esc(r['customer_name']))
                + '<span class="time">%s -> %s</span><br>' % (esc(r['start_date']), esc(r['end_date']))
                + '%s - %s ч.<br>' % (esc(r['name']), esc(r['duration_hours']))
                + '<span class="muted">Исполнитель: %s</span><br>' % esc(r['workers'] or 'не назначен')
                + '<a class="calendar_open" href="/chain?id=%s&user=%s">Открыть заказ</a>' % (r['order_id'], uid)
                + '<span class="draghint">%s</span></div>' % hint
            )
        if not blocks: blocks='<span class="small muted">Работы не ставятся</span>' if (weekend or holiday) else '<span class="small muted">Нет работ</span>'
        cells.append(f'<div class="day {cls} dropday" data-date="{year}-{month:02d}-{d:02d}"><b>{d} Июнь</b><br><span class="small">{schedule}</span><hr style="border-color:#1f2937">{blocks}</div>')
    moves=con.execute("select cm.*,u.name mover,o.order_number,ps.name step_name from calendar_moves cm left join users u on u.id=cm.moved_by left join orders o on o.id=cm.order_id left join production_steps ps on ps.id=cm.step_id order by cm.id desc limit 12").fetchall(); con.close()
    move_rows=''.join([f'<tr><td>{esc(m["order_number"])}</td><td>{esc(m["step_name"])}</td><td>{esc(m["old_start"])} -> {esc(m["new_start"])}</td><td>{esc(m["mover"])}</td><td>{esc(m["created_at"])}</td></tr>' for m in moves]) or '<tr><td colspan="5">Переносов пока нет</td></tr>'
    note='<div class="notice">Режим редактирования: Юлия и Сергей могут переносить задачи и включать 🔥.</div>' if can else '<div class="readonly">Только просмотр. Переносить задачи и включать 🔥 могут только Юлия и Сергей.</div>'
    return layout('Календарь',f'<div class="card"><h1>Календарь выполнения заказов</h1>{note}<div class="legend"><span>Синий — рабочий день</span><span>Жёлтый — сокращенный</span><span>Красный — праздник</span><span>Тёмный — выходной</span></div><div class="orderlegend">{"".join(legend)}</div><div class="calendar">{"".join(cells)}</div>{calendar_script(uid)}</div><div class="card"><h2>История переносов календаря</h2><table><tr><th>Заказ</th><th>Звено</th><th>Перенос</th><th>Кто перенёс</th><th>Когда</th></tr>{move_rows}</table></div>',uid)

def move_step(uid,step_id,new_date):
    if not can_edit_calendar(uid): return False,'Нет прав переносить задачи'
    con=db(); st=con.execute('select * from production_steps where id=?',(step_id,)).fetchone()
    if not st: con.close(); return False,'Этап не найден'
    try: old_start=datetime.strptime(st['start_date'][:16],'%Y-%m-%d %H:%M')
    except Exception: old_start=datetime(2026,6,3,9,0)
    target=datetime.strptime(new_date,'%Y-%m-%d'); new_start=target.replace(hour=old_start.hour if 9<=old_start.hour<18 else 9,minute=old_start.minute if 0<=old_start.minute<60 else 0); new_end=add_hours(new_start,st['duration_hours'] or 1)
    con.execute('update production_steps set start_date=?,end_date=?,manual_locked=1,moved_at=? where id=?',(new_start.strftime('%Y-%m-%d %H:%M'),new_end.strftime('%Y-%m-%d %H:%M'),now_sql(),step_id))
    cursor=new_end
    for nx in con.execute('select * from production_steps where order_id=? and sort_order>? order by sort_order,id',(st['order_id'],st['sort_order'])).fetchall():
        ns=cursor; ne=add_hours(ns,nx['duration_hours'] or 1); con.execute('update production_steps set start_date=?,end_date=? where id=?',(ns.strftime('%Y-%m-%d %H:%M'),ne.strftime('%Y-%m-%d %H:%M'),nx['id'])); cursor=ne
    con.execute('insert into calendar_moves(step_id,order_id,moved_by,old_start,old_end,new_start,new_end,note,created_at) values(?,?,?,?,?,?,?,?,?)',(step_id,st['order_id'],uid,st['start_date'],st['end_date'],new_start.strftime('%Y-%m-%d %H:%M'),new_end.strftime('%Y-%m-%d %H:%M'),'Ручной перенос',now_sql()))
    con.commit(); con.close(); return True,'ok'

def render_tasks(uid):
    con=db(); rows=con.execute('select t.*,o.order_number,o.customer_name,u.name from_user from tasks t join orders o on o.id=t.order_id left join users u on u.id=t.from_user_id where t.to_user_id=? order by t.id desc',(uid,)).fetchall(); con.close(); html=''.join([f'<a class="task" href="/chain?id={t["order_id"]}&user={uid}"><b>Задача для вас</b><br><span class="muted">От: {esc(t["from_user"])} - {esc(t["order_number"])} - {esc(t["customer_name"])}</span><p>{esc(t["message"])}</p></a>' for t in rows]) or '<div class="readonly">Открытых задач нет.</div>'; return layout('Мои задачи',f'<div class="card"><h1>Мои задачи</h1>{html}</div>',uid)

def render_order(uid,oid):
    con=db(); o=con.execute('select * from orders where id=?',(oid,)).fetchone(); steps=con.execute('select * from production_steps where order_id=? order by sort_order,id',(oid,)).fetchall(); con.close()
    if not o: return layout('Нет заказа','<div class="card">Заказ не найден</div>',uid)
    stages=''.join([f'<div class="stage {"done" if i<o["current_stage_index"] else "current" if i==o["current_stage_index"] else ""}">{i+1}. {esc(st)}</div>' for i,st in enumerate(STAGES)]); chain=''.join([f'<div class="chainitem" style="background:{esc(st["color"] or "#3b82f6")}">{esc(st["name"])}<small>{esc(st["start_date"])} -> {esc(st["end_date"])}<br>{esc(st["duration_hours"])} ч.</small></div>' for st in steps]); urgent='<span class="badge">🔥 СРОЧНЫЙ</span>' if o['is_urgent'] else ''
    return layout('Заказ',f'<div class="card"><h1>{esc(o["order_number"])} — {esc(o["customer_name"])} {urgent}</h1><div class="stagebar">{stages}</div><a class="btn" href="/calendar?user={uid}">Календарь</a></div><div class="card"><h2>Коротко</h2><p><b>Заказ:</b> {esc(o["short_description"])}</p><p><b>Сумма:</b> {money(o["price_total"])} ₽ - <b>Оплачено:</b> {money(o["paid_amount"])} ₽ - <b>Остаток:</b> {money(o["remaining_amount"])} ₽</p></div><div class="card"><h2>Цепочка выполнения</h2><div class="chain">{chain}</div></div>',uid)

def render_new(uid): return layout('Новый заказ',f'<div class="card"><h1>Создать заказ</h1><form method="post" action="/create"><input type="hidden" name="user" value="{uid}"><div class="grid"><input name="customer_name" placeholder="Имя заказчика" required><input name="customer_phone" placeholder="Телефон"><input name="short_description" placeholder="Что нужно" required><input name="price_total" placeholder="Сумма" value="0"></div><br><button class="btn">Создать</button></form></div>',uid)
def render_workers(uid):
    con=db(); rows=con.execute('select * from workers').fetchall(); con.close(); html=''.join([f'<tr><td>{esc(w["full_name"])}</td><td>{esc(w["position"])}</td></tr>' for w in rows]); return layout('Рабочие',f'<div class="card"><h1>Рабочие</h1><table><tr><th>ФИО</th><th>Должность</th></tr>{html}</table></div>',uid)

class Handler(BaseHTTPRequestHandler):
    def send_text(self,txt,status=200):
        b=txt.encode('utf-8'); self.send_response(status); self.send_header('Content-Type','text/plain; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def send_file(self,path,ctype):
        data=open(path,'rb').read()
        self.send_response(200)
        self.send_header('Content-Type',ctype)
        fname='skwest_export.zip' if 'zip' in ctype else 'skwest_export.xlsx'
        self.send_header('Content-Disposition','attachment; filename="'+fname+'"')
        self.send_header('Content-Length',str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_html(self,html):
        b=html.encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def redir(self,url): self.send_response(303); self.send_header('Location',url); self.end_headers()
    def post_data(self): raw=self.rfile.read(int(self.headers.get('content-length',0))).decode('utf-8','replace'); return {k:v[0] for k,v in parse_qs(raw).items()}
    def do_GET(self):
        p=urlparse(self.path); q=parse_qs(p.query); uid=int(q.get('user',['1'])[0])
        if p.path.startswith('/assets/'):
            fp=os.path.join(BASE_DIR,'assets',os.path.basename(p.path))
            if os.path.exists(fp): data=open(fp,'rb').read(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(fp)[0] or 'application/octet-stream'); self.end_headers(); self.wfile.write(data); return
        if p.path=='/login': return self.send_html(render_login())
        if p.path=='/logout':
            self.send_response(302); self.send_header('Set-Cookie',SESSION_COOKIE+'=; Path=/; Max-Age=0'); self.send_header('Location','/login'); self.end_headers(); return
        if not uid: return self.redir('/login')
        if p.path=='/profile': return self.send_html(render_profile(uid))
        if p.path=='/': return self.send_html(render_dashboard(uid))
        if p.path=='/timer': return self.send_html(render_timer_page(uid))
        if p.path=='/finance': return self.send_html(render_finance_page(uid, q.get('type',['active'])[0]))
        if p.path=='/exports': return self.send_html(render_exports_page(uid))
        if p.path=='/order_table': return self.send_html(render_order_table(uid))
        if p.path=='/order_table_xlsx':
            path=filled_order_table_xlsx()
            return self.send_file(path,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        if p.path=='/export_zip':
            path=create_export_zip(q.get('type',['all'])[0])
            return self.send_file(path,'application/zip')
        if p.path=='/orders': return self.send_html(render_orders_page(uid))
        if p.path=='/production': return self.send_html(render_production_page(uid))
        if p.path=='/orders_calendar': return self.send_html(render_orders_calendar(uid))
        if p.path=='/tasks_calendar': return self.send_html(render_daily_tasks_calendar(uid))
        if p.path=='/task': return self.send_html(render_task_detail(uid,int(q.get('id',[0])[0])))
        if p.path=='/new_task': return self.send_html(render_new_task(uid))
        if p.path=='/calendar': return self.send_html(render_calendar(uid))
        if p.path=='/tasks': return self.send_html(render_tasks(uid))
        if p.path in ('/order','/chain'): return self.send_html(render_order(uid,int(q.get('id',['1'])[0])))
        if p.path=='/new': return self.send_html(render_new(uid))
        if p.path=='/delete_worker':
            if is_workshop_user(uid):
                con=db(); con.execute('update workshop_workers set is_active=0 where id=?',(int(q.get('id',[0])[0]),)); con.commit(); con.close()
            return self.redir('/workers?user=%s'%uid)
        if p.path=='/delete_team':
            if is_workshop_user(uid):
                con=db(); con.execute('update workshop_teams set is_active=0 where id=?',(int(q.get('id',[0])[0]),)); con.commit(); con.close()
            return self.redir('/teams?user=%s'%uid)
        if p.path=='/access_check': return self.send_html(render_access_check(uid))
        if p.path=='/workers': return self.send_html(render_workshop_workers(uid))
        if p.path=='/edit_team': return self.send_html(render_edit_team(uid,int(q.get('id',[0])[0])))
        if p.path=='/teams': return self.send_html(render_workshop_teams(uid))
        if p.path=='/assign_production': return self.send_html(render_assign_production(uid,int(q.get('id',[1])[0])))
        return self.send_html(layout('Ошибка','<div class="card">Страница не найдена</div>',uid))
    def do_POST(self):
        data=self.post_data(); uid=int(data.get('user',1))
        if self.path=='/save_order_table':
            con=db()
            for k,v in data.items():
                if not k.startswith('cell_'): continue
                parts=k.split('_')
                if len(parts)!=3: continue
                try:
                    oid=int(parts[1]); ci=int(parts[2])
                except Exception: continue
                con.execute('insert or replace into order_table_overrides(order_id,col_index,value,updated_by,updated_at) values(?,?,?,?,?)',(oid,ci,v,uid,now_sql()))
            con.commit(); con.close()
            return self.redir('/order_table?user=%s'%uid)

        if self.path=='/move_step_calendar':
            ok,msg=move_step(uid,int(data.get('step_id',0)),data.get('new_date',''))
            return self.send_text(msg,200 if ok else 403)
        if self.path=='/toggle_urgent_ajax':
            if not can_edit_calendar(uid): return self.send_text('Нет прав менять срочность',403)
            oid=int(data.get('id',0)); con=db(); o=con.execute('select * from orders where id=?',(oid,)).fetchone()
            if not o: con.close(); return self.send_text('Заказ не найден',404)
            val=0 if int(o['is_urgent'] or 0)==1 else 1; con.execute('update orders set is_urgent=?,updated_at=? where id=?',(val,now_sql(),oid)); con.commit(); con.close(); return self.send_text(str(val))
        if self.path=='/create':
            con=db(); num='CRM-'+datetime.now().strftime('%Y%m%d-%H%M%S'); price=float(data.get('price_total') or 0); con.execute('insert into orders(order_number,customer_name,customer_phone,short_description,current_stage,current_stage_index,price_total,remaining_amount,total_items,item_name,created_at,updated_at) values(?,?,?,?,?,?,?,?,?,?,?,?)',(num,data.get('customer_name'),data.get('customer_phone'),data.get('short_description'),'Новый заказ',0,price,price,1,'изделий',now_sql(),now_sql())); oid=con.execute('select last_insert_rowid() id').fetchone()['id']; con.execute('insert into tasks(order_id,from_user_id,to_user_id,stage,message,created_at) values(?,?,?,?,?,?)',(oid,uid,uid,'Новый заказ','Проверь заявку и передай Юлии.',now_sql())); con.commit(); con.close(); return self.redir(f'/tasks?user={uid}')
        return self.send_text('OK')

def open_browser():
    try:
        webbrowser.open(f'http://127.0.0.1:{PORT}')
    except Exception:
        pass

if __name__=='__main__':
    init_db()
    HOST=os.environ.get('SKWEST_HOST','0.0.0.0')
    if os.environ.get('SKWEST_OPEN_BROWSER','0')=='1':
        threading.Timer(1.0,open_browser).start()
    print(f'SK WEST CRM V66 started: http://{HOST}:{PORT}')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()