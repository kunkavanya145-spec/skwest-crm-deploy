@echo off
chcp 65001 > nul
title SK WEST CRM V81 - start
cd /d "%~dp0"
echo ========================================
echo SK WEST CRM V81 - start
echo Address: http://127.0.0.1:8172
echo ========================================
set PYTHON_CMD=
where py >nul 2>nul
if %errorlevel%==0 set PYTHON_CMD=py
if "%PYTHON_CMD%"=="" (
  where python >nul 2>nul
  if %errorlevel%==0 set PYTHON_CMD=python
)
if "%PYTHON_CMD%"=="" (
  echo Python was not found.
  pause
  exit /b 1
)
%PYTHON_CMD% crm_app\app.py
pause
